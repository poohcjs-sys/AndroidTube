# 유튜브 다운로더 0.3.0 앱 소스

YouTube 링크 복사 → 입력란 탭으로 붙여넣기 → 형식·음원 품질·저장 폴더 선택 → 다운로드.
기존 모아 저장의 업데이트이며 패키지 ID는 kr.co.androidtube.pocketsave입니다.
사용법과 검증 범위는 USAGE.md 및 validation.txt에 있습니다.

Android Studio에서 이 디렉터리를 엽니다. JDK 17 / Android SDK 35가 필요합니다.

```sh
./gradlew :pocket:testDebugUnitTest :pocket:assembleDebug :pocket:lintDebug -PmoaScreenshots
```

APK: pocket/build/outputs/apk/debug
의존성은 Google Maven과 Maven Central에서 받습니다.
라이선스와 고정된 외부 구성요소 소스: pocket/LICENSE, pocket/THIRD_PARTY.md.
제공 APK의 서명키는 포함하지 않습니다. 직접 빌드하면 서명이 달라 기존 제공 APK 위에 업데이트되지 않을 수 있습니다.
기존 차량용 앱은 포함하지 않습니다.

실제 YouTube 다운로드 및 S23 설치는 클라우드에서 확인하지 못했습니다.
Android 11 이상 ARM64 / 4 KB 메모리 페이지용입니다. 16 KB 기기는 기존 네이티브 라이브러리 제한으로 지원하지 않습니다.
