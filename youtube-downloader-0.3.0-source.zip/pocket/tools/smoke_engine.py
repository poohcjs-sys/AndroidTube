#!/usr/bin/env python3
"""Offline engine/FFmpeg smoke test using generated media, not a YouTube download.
Usage: python3 smoke_engine.py /path/to/bundled-ytdlp /tmp/moa-smoke
Requires host Python and ffmpeg/ffprobe. Does not validate Android native execution.
"""
import json
import pathlib
import subprocess
import sys

engine = pathlib.Path(sys.argv[1]).resolve()
root = pathlib.Path(sys.argv[2]).resolve()
root.mkdir(parents=True, exist_ok=True)
video, audio = root / 'source.mp4', root / 'source.m4a'
def run(args):
    return subprocess.run(args, check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc2=size=320x180:rate=15', '-t', '2', '-an', '-c:v', 'libx264', '-threads', '1', str(video)])
run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'anoisesrc=color=pink:sample_rate=48000:seed=1234',
     '-t', '8', '-ac', '2', '-c:a', 'aac', '-b:a', '320k', str(audio)])
fixture = {'id': 'BaW_jenozKc', 'title': '유튜브 다운로더 합성 영상', 'extractor': 'generic', 'duration': 8,
           'is_live': False, 'is_upcoming': False, 'webpage_url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
           'formats': [
               {'format_id': 'v', 'url': video.as_uri(), 'ext': 'mp4', 'vcodec': 'avc1.64000d', 'acodec': 'none', 'height': 180, 'width': 320},
               {'format_id': 'a', 'url': audio.as_uri(), 'ext': 'm4a', 'vcodec': 'none', 'acodec': 'mp4a.40.2', 'abr': 320}]}
metadata = root / 'fixture.json'
metadata.write_text(json.dumps(fixture))
cases = [('video720', ''), ('m4a', 'original')]
cases += [('mp3', rate) for rate in ('128', '192', '256', '320')]
cases += [('m4a', rate) for rate in ('128', '192', '256')]
for mode, quality in cases:
    directory = root / (mode + ('-' + quality if quality else ''))
    directory.mkdir(exist_ok=True)
    command = [sys.executable, str(engine), '--ignore-config', '--no-playlist', '--no-colors', '--no-mtime',
               '--enable-file-urls', '--load-info-json', str(metadata), '--no-simulate',
               '--match-filter', '!is_live & !is_upcoming',
               '--print-to-file', 'after_move:%(filepath)s', str(directory / 'result-path.txt'),
               '--print-to-file', 'after_move:%(title)s', str(directory / 'title.txt'),
               '-o', str(directory / 'media.%(ext)s')]
    if mode.startswith('video'):
        command += ['-f', 'bv[height<=720][ext=mp4][vcodec^=avc1]+ba[ext=m4a]/b[height<=720][ext=mp4]/bv[height<=720]+ba/b[height<=720]', '--merge-output-format', 'mp4/mkv']
    else:
        command += ['-f', 'ba[ext=m4a]/ba/b', '-x', '--audio-format', mode, '--audio-quality', quality + 'K' if mode == 'mp3' else '0']
    try:
        run(command)
    except subprocess.CalledProcessError as error:
        print(error.stdout, error.stderr)
        raise
    output = pathlib.Path((directory / 'result-path.txt').read_text().strip().splitlines()[-1])
    assert output.parent == directory and output.stat().st_size > 0
    if mode == 'm4a' and quality != 'original':
        encoded = directory / 'media.encoded.m4a'
        # Same arguments as AudioTranscoder.command; the Java unit tests check that mapping.
        run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-i', str(output),
             '-map', '0:a:0', '-vn', '-c:a', 'aac', '-b:a', quality + 'k', '-movflags', '+faststart', str(encoded)])
        output = encoded
    probe = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-of', 'json', str(output)]).stdout)
    types = [s['codec_type'] for s in probe['streams']]
    assert 'audio' in types
    assert ('video' in types) == mode.startswith('video')
    stream = next(s for s in probe['streams'] if s['codec_type'] == 'audio')
    bitrate = int(stream.get('bit_rate', 0))
    if quality.isdigit():
        requested = int(quality) * 1000
        # AAC is an average target; MP3 is constant bitrate. Both must match this noise fixture.
        tolerance = .05 if mode == 'mp3' else .25
        assert abs(bitrate - requested) <= requested * tolerance, (mode, quality, bitrate)
    print(mode, quality, 'OK', output.name, types, 'audio_bitrate=' + str(bitrate))
