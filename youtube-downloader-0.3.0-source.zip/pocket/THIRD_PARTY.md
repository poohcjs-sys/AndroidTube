# 유튜브 다운로더(이전 이름: 모아 저장)의 소스와 외부 구성요소

이 디렉터리의 새 앱 코드는 GPL-3.0-only로 제공합니다. 전문은 `LICENSE`에 있습니다. 이 선언은 기존 차량 앱의 라이선스를 변경하지 않습니다.

앱은 별도 다운로드 서버를 사용하지 않고 휴대폰에서 실행합니다. 아래 구성요소를 수정하지 않고 사용합니다.

| 구성요소 | 버전·라이선스 | 소스 / 빌드 안내 |
| --- | --- | --- |
| youtubedl-android library, common, ffmpeg | 0.18.1 · GPL-3.0 | https://github.com/yausername/youtubedl-android/tree/0.18.1 |
| yt-dlp 기본 포함 실행 파일 | 2025.11.12 · Unlicense 및 포함 모듈별 라이선스 | https://github.com/yt-dlp/yt-dlp/tree/2025.11.12 |
| Python / Android 실행 환경 | 상위 라이브러리의 사전 빌드 · PSF 및 모듈별 라이선스 | https://github.com/yausername/youtubedl-android/blob/0.18.1/BUILD_PYTHON.md |
| FFmpeg 및 코덱 라이브러리 | 상위 라이브러리의 사전 빌드 · LGPL/GPL 및 모듈별 라이선스 | https://github.com/yausername/youtubedl-android/blob/0.18.1/BUILD_FFMPEG.md |
| QuickJS | 상위 라이브러리 포함 · MIT | https://github.com/yausername/youtubedl-android/tree/0.18.1 |
| Kotlin / AndroidX / Jackson | 각 Maven 전이 의존성 · Apache-2.0 | `./gradlew :pocket:dependencies --configuration debugRuntimeClasspath` |
| Commons IO | 전이 의존성 · Apache-2.0 | https://commons.apache.org/proper/commons-io/ |

정확한 Android 의존성은 `build.gradle`에 고정합니다. Maven Central의 원본 AAR 및 소스 JAR:

https://repo.maven.apache.org/maven2/io/github/junkfood02/youtubedl-android/

앱의 ‘다운로드 기능 업데이트’는 공식 `yt-dlp/yt-dlp` 저장소의 stable 릴리스에서 `yt-dlp`와 `SHA2-256SUMS`를 받아 검증합니다. 업데이트한 버전은 화면에 표시합니다. 다운로드 엔진의 추가 구성요소 라이선스는 해당 릴리스의 LICENSE 및 THIRD_PARTY_LICENSES를 함께 참고하세요. 체크섬은 전송 일관성을 검사하는 것이며, 별도의 서명 검증이라고 설명하지 않습니다.

사용자용 소스 압축에는 이 모듈, Gradle 빌드 설정·wrapper 및 테스트를 포함합니다. 새 앱만 빌드하도록 압축 안의 `settings.gradle`을 구성하며 기존 차량 앱 소스는 필요하지 않습니다. 네이티브 구성요소를 다시 빌드하려면 위의 고정된 상위 소스 및 빌드 문서가 필요합니다.
