package kr.co.androidtube.pocketsave;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.function.BooleanSupplier;

/** Updates only the official stable executable, with bounded IO and release checksum verification. */
final class EngineUpdater {
    private static final String RELEASE = "https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest";
    static boolean due(Context c) {
        return System.currentTimeMillis() - c.getSharedPreferences("engine", 0).getLong("attempted", 0) > 86400000L;
    }
    static String version(Context c) { return c.getSharedPreferences("engine", 0).getString("version", "기본 포함 버전"); }
    static String update(Context c, BooleanSupplier cancelled) throws Exception {
        c.getSharedPreferences("engine", 0).edit().putLong("attempted", System.currentTimeMillis()).apply();
        JSONObject release = new JSONObject(new String(bytes(RELEASE, 2_000_000, cancelled), StandardCharsets.UTF_8));
        String version = release.getString("tag_name");
        if (version.equals(version(c))) {
            c.getSharedPreferences("engine", 0).edit().putLong("checked", System.currentTimeMillis()).apply();
            return version;
        }
        String binary = null, sums = null;
        JSONArray assets = release.getJSONArray("assets");
        for (int i = 0; i < assets.length(); i++) {
            JSONObject asset = assets.getJSONObject(i);
            String name = asset.getString("name");
            String url = asset.getString("browser_download_url");
            if (!url.startsWith("https://github.com/yt-dlp/yt-dlp/releases/download/")) continue;
            if (name.equals("yt-dlp")) binary = url;
            if (name.equals("SHA2-256SUMS")) sums = url;
        }
        if (binary == null || sums == null) throw new IOException("공식 업데이트 파일을 찾지 못했습니다.");
        String checksum = checksum(new String(bytes(sums, 200_000, cancelled), StandardCharsets.UTF_8));
        File directory = new File(c.getNoBackupFilesDir(), "youtubedl-android/yt-dlp");
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("업데이트 공간을 만들지 못했습니다.");
        File temp = new File(directory, "update.tmp");
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (OutputStream out = Files.newOutputStream(temp.toPath())) {
                transfer(binary, 50_000_000, cancelled, out, digest);
            }
            StringBuilder actual = new StringBuilder();
            for (byte b : digest.digest()) actual.append(String.format(Locale.ROOT, "%02x", b & 255));
            if (!actual.toString().equals(checksum)) throw new IOException("업데이트 파일 검증에 실패했습니다.");
            if (cancelled.getAsBoolean()) throw new CancellationException();
            Files.move(temp.toPath(), new File(directory, "yt-dlp").toPath(),
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            c.getSharedPreferences("engine", 0).edit().putString("version", version)
                    .putLong("checked", System.currentTimeMillis()).apply();
            return version;
        } finally { temp.delete(); }
    }
    static String checksum(String sums) throws IOException {
        for (String line : sums.split("\\R")) {
            String[] parts = line.trim().split("\\s+", 2);
            if (parts.length == 2 && (parts[1].equals("yt-dlp") || parts[1].equals("*yt-dlp"))
                    && parts[0].matches("[a-fA-F0-9]{64}")) return parts[0].toLowerCase(Locale.ROOT);
        }
        throw new IOException("업데이트 검증 정보를 찾지 못했습니다.");
    }
    private static byte[] bytes(String url, int limit, BooleanSupplier cancelled) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        transfer(url, limit, cancelled, out, null); return out.toByteArray();
    }
    private static void transfer(String address, int limit, BooleanSupplier cancelled,
                                 OutputStream output, MessageDigest digest) throws IOException {
        for (int redirect = 0; redirect < 6; redirect++) {
            if (cancelled.getAsBoolean()) throw new CancellationException();
            URL url = new URL(address);
            if (!url.getProtocol().equals("https")) throw new IOException("보안 연결이 필요합니다.");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10000); connection.setReadTimeout(10000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", "MoaSave/0.1.0");
            try {
                int status = connection.getResponseCode();
                if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                    String location = connection.getHeaderField("Location");
                    if (location == null) throw new IOException("업데이트 응답이 올바르지 않습니다.");
                    address = new URL(url, location).toString(); continue;
                }
                if (status != 200) throw new IOException("업데이트 서버 응답: " + status);
                try (InputStream in = connection.getInputStream()) {
                    byte[] buffer = new byte[65536]; int total = 0;
                    for (int n; (n = in.read(buffer)) != -1;) {
                        if (cancelled.getAsBoolean()) throw new CancellationException();
                        total += n;
                        if (total > limit) throw new IOException("업데이트 파일의 크기가 예상 범위를 벗어났습니다.");
                        output.write(buffer, 0, n);
                        if (digest != null) digest.update(buffer, 0, n);
                    }
                }
                return;
            } finally { connection.disconnect(); }
        }
        throw new IOException("업데이트 서버 연결이 반복되었습니다.");
    }
}
