package kr.co.androidtube.pocketsave;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.concurrent.CancellationException;
import java.util.function.BooleanSupplier;

/** A user-selected tree, with an identifiable staging document until the copy is complete. */
final class DocumentPublisher {
    static SaveStore.Item publish(Context context, SaveDestination.Target target, File file, String title,
                                  String suffix, BooleanSupplier cancelled) throws IOException {
        SaveDestination.validate(context, target);
        if (cancelled.getAsBoolean()) throw new CancellationException();
        var resolver = context.getContentResolver();
        SaveStore store = new SaveStore(context);
        String name = MediaPublisher.safeTitle(title) + "_" + suffix + "." + MediaPublisher.extension(file);
        String mime = MediaPublisher.mime(MediaPublisher.extension(file));
        String temporary = "yt-download-" + java.util.UUID.randomUUID() + ".partial";
        Uri uri = DocumentsContract.createDocument(resolver, target.directory(), mime, temporary);
        if (uri == null) throw new IOException("선택한 저장 폴더에 파일을 만들지 못했습니다.");
        boolean committed = false;
        try {
            store.pendingDocument(uri.toString(), temporary);
            try (InputStream input = Files.newInputStream(file.toPath()); OutputStream output = resolver.openOutputStream(uri, "w")) {
                if (output == null) throw new IOException("선택한 저장 폴더에 쓸 수 없습니다.");
                MediaPublisher.copy(input, output, cancelled);
            }
            if (cancelled.getAsBoolean()) throw new CancellationException();
            Uri completed = DocumentsContract.renameDocument(resolver, uri, name);
            if (completed == null) throw new IOException("저장 폴더에서 파일 이름을 확정할 수 없습니다. 다른 폴더를 선택해 주세요.");
            committed = true;
            return new SaveStore.Item(completed.toString(), name, mime, System.currentTimeMillis());
        } finally {
            if (!committed) DocumentsContract.deleteDocument(resolver, uri);
            store.pending(null);
        }
    }
    static void recover(Context context, String pending, String prefix) throws IOException {
        Uri uri = Uri.parse(pending);
        // Providers may preserve or replace a URI on rename. Never delete a completed document.
        try (Cursor cursor = context.getContentResolver().query(uri,
                new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                if (name != null && name.startsWith(prefix)) DocumentsContract.deleteDocument(context.getContentResolver(), uri);
            }
        }
    }
}
