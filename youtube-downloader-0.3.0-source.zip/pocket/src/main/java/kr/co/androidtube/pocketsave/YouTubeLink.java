package kr.co.androidtube.pocketsave;

import java.net.URI;
import java.net.URLDecoder;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Only a single canonical public video URL leaves this parser. No redirects or arbitrary hosts. */
final class YouTubeLink {
    private static final Pattern URL = Pattern.compile("https?://[^\\s<>\\\"]+", Pattern.CASE_INSENSITIVE);
    private static final Pattern ID = Pattern.compile("[A-Za-z0-9_-]{11}");
    private static final Set<String> HOSTS = Set.of("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com");

    static String parse(String text) {
        if (text == null || text.length() > 16000) throw invalid();
        String trimmed = text.trim();
        if (trimmed.matches("(?i)^(www\\.|m\\.|music\\.)?youtube\\.com/.*") || trimmed.startsWith("youtu.be/")) {
            trimmed = "https://" + trimmed;
        }
        Matcher matcher = URL.matcher(trimmed);
        while (matcher.find()) {
            String token = matcher.group().replaceAll("[)\\]。,!?]+$", "");
            try {
                URI uri = URI.create(token);
                if (uri.getUserInfo() != null || uri.getPort() != -1 || uri.getHost() == null) continue;
                String host = uri.getHost().toLowerCase(Locale.ROOT);
                String path = uri.getPath();
                String id = null;
                if (host.equals("youtu.be") || host.equals("www.youtu.be")) {
                    if (path.matches("/[A-Za-z0-9_-]{11}/?")) id = path.substring(1, 12);
                } else if (HOSTS.contains(host)) {
                    if ("/watch".equals(path) && uri.getRawQuery() != null) {
                        for (String part : uri.getRawQuery().split("&")) {
                            String[] pair = part.split("=", 2);
                            if (pair.length == 2 && pair[0].equals("v")) {
                                id = URLDecoder.decode(pair[1], "UTF-8"); break;
                            }
                        }
                    } else if (path.matches("/(shorts|live|embed)/[A-Za-z0-9_-]{11}/?")) {
                        id = path.split("/")[2];
                    }
                }
                if (id != null && ID.matcher(id).matches()) return "https://www.youtube.com/watch?v=" + id;
            } catch (IllegalArgumentException | java.io.UnsupportedEncodingException ignored) { }
        }
        throw invalid();
    }

    private static IllegalArgumentException invalid() {
        return new IllegalArgumentException("YouTube 영상 링크를 붙여 넣어 주세요. 채널·재생목록 링크는 지원하지 않습니다.");
    }
}
