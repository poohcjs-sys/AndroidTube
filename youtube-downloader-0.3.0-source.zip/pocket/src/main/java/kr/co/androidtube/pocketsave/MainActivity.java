package kr.co.androidtube.pocketsave;

import static kr.co.androidtube.pocketsave.StudioStyle.*;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int PICK_FOLDER = 18;
    private enum Page { LINK, FORMAT, TRANSFER, LIBRARY }
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, LinearLayout> choices = new LinkedHashMap<>();
    private final Map<String, TextView> choiceMarks = new LinkedHashMap<>();
    private StudioStyle ui;
    private SaveStore store;
    private Page page = Page.LINK;
    private String draft = "", confirmed = "", selected = "";
    private String lastAutoClipboard = "";
    private boolean starting, startUpdate;
    private String previousTaskId = "";
    private long startedAt;
    private EditText url;
    private LinearLayout root, body, footer, activeBanner;
    private TextView inputError, footerHint, activeText, transferTitle, transferMessage, transferPercent, transferDetail;
    private TextView transferSymbol, transferTag, libraryCount;
    private Button action, transferSecondary, qualityButton, folderButton;
    private ProgressBar progress;
    private String renderedPhase = "", renderedItems = "";
    private LinearLayout recent;
    private SaveStore.Item completion;
    private final Runnable refresh = new Runnable() {
        @Override public void run() { renderState(); handler.postDelayed(this, 650); }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ui = new StudioStyle(this); store = new SaveStore(this);
        if (!SaveService.running) {
            MediaPublisher.recover(this);
            if (store.state().busy()) store.state("failed", "이전 다운로드가 중단되었습니다. 다시 시도해 주세요.", -1, "");
        }
        draft = getPreferences(0).getString("link", "");
        if (state != null) {
            draft = state.getString("draft", draft); confirmed = state.getString("confirmed", ""); selected = state.getString("selected", "");
            starting = state.getBoolean("starting"); startUpdate = state.getBoolean("startUpdate"); startedAt = state.getLong("startedAt");
            previousTaskId = state.getString("previousTaskId", "");
            lastAutoClipboard = state.getString("lastAutoClipboard", "");
            try { page = Page.valueOf(state.getString("page", "LINK")); } catch (IllegalArgumentException ignored) { }
            if (!SaveRequest.MODES.contains(selected)) selected = "";
            if (page == Page.FORMAT) {
                try { if (!YouTubeLink.parse(draft).equals(confirmed)) page = Page.LINK; }
                catch (IllegalArgumentException invalid) { page = Page.LINK; }
            }
        } else if (SaveService.running || store.state().busy()) page = Page.TRANSFER;
        if (state == null) acceptShare(getIntent());
        getWindow().setDecorFitsSystemWindows(false);
        show(page);
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (acceptShare(intent)) show(Page.LINK); else if (busy()) show(Page.TRANSFER);
    }
    private boolean acceptShare(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return false;
        String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (shared == null) return false;
        try { draft = YouTubeLink.parse(shared); confirmed = ""; selected = ""; page = Page.LINK; return true; }
        catch (IllegalArgumentException invalid) { tell("링크를 확인해 주세요", invalid.getMessage()); return false; }
    }
    @Override protected void onResume() { super.onResume(); handler.removeCallbacks(refresh); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); remember(); super.onPause(); }
    private void remember() { getPreferences(0).edit().putString("link", draft).apply(); }
    @Override protected void onSaveInstanceState(Bundle state) {
        state.putString("draft", draft); state.putString("confirmed", confirmed); state.putString("selected", selected);
        state.putString("page", page.name()); state.putBoolean("starting", starting); state.putBoolean("startUpdate", startUpdate);
        state.putLong("startedAt", startedAt); state.putString("previousTaskId", previousTaskId);
        state.putString("lastAutoClipboard", lastAutoClipboard);
        super.onSaveInstanceState(state);
    }
    @Override public void onBackPressed() {
        if (page == Page.FORMAT || page == Page.LIBRARY || page == Page.TRANSFER) show(Page.LINK);
        else super.onBackPressed();
    }

    private void show(Page destination) {
        page = destination;
        url = null; inputError = null; action = null; transferSecondary = null; activeBanner = null;
        qualityButton = null; folderButton = null;
        choices.clear(); choiceMarks.clear(); renderedPhase = ""; renderedItems = "";
        root = ui.column(); root.setId(R.id.screen_root); root.setBackgroundColor(PAPER);
        root.setFocusableInTouchMode(true);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets space = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
            v.setPadding(space.left, space.top, space.right, space.bottom); return insets;
        });
        header();
        FrameLayout center = new FrameLayout(this);
        root.addView(center, new LinearLayout.LayoutParams(-1, 0, 1));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        int width = getResources().getConfiguration().screenWidthDp > 600 ? ui.dp(560) : -1;
        center.addView(scroll, new FrameLayout.LayoutParams(width, -1, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        body = ui.column(); body.setId(R.id.page_body); body.setPadding(ui.dp(24), ui.dp(8), ui.dp(24), ui.dp(24));
        scroll.addView(body);
        footer = ui.column(); footer.setPadding(ui.dp(24), ui.dp(12), ui.dp(24), ui.dp(12));
        root.addView(footer);
        switch (page) {
            case LINK -> inputPage();
            case FORMAT -> formatPage();
            case TRANSFER -> transferPage();
            case LIBRARY -> libraryPage();
        }
        bottomNavigation();
        setContentView(root); root.requestApplyInsets(); root.requestFocus(); renderState();
    }
    private void header() {
        LinearLayout h = ui.row(); h.setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(8));
        if (page == Page.FORMAT) {
            TextView back = ui.iconButton("back", "링크 입력으로 돌아가기"); back.setId(R.id.link_edit);
            back.setOnClickListener(v -> show(Page.LINK)); h.addView(back);
        }
        LinearLayout brand = ui.row(); brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = ui.text("Y", 22, LIGHT_GOLD, false); mark.setGravity(Gravity.CENTER);
        mark.setTypeface(Typeface.create("serif", Typeface.NORMAL)); mark.setBackground(ui.shape(INK, 12, 0));
        brand.addView(mark, new LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)));
        LinearLayout names = ui.column(); names.setPadding(ui.dp(10), 0, 0, 0);
        TextView name = ui.text(getString(R.string.app_name), 16, INK, true); names.addView(name);
        TextView sub = ui.label("VIDEO & AUDIO COLLECTION"); sub.setTextSize(8); ui.add(names, sub, 5); brand.addView(names);
        h.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView settings = ui.iconButton("settings", "설정 및 사용 안내"); settings.setOnClickListener(v -> settings()); h.addView(settings);
        root.addView(h);
    }
    private void step(int position) {
        LinearLayout row = ui.row();
        String[] labels = {"링크 입력", "형식 선택", "다운로드"};
        for (int i = 0; i < labels.length; i++) {
            TextView t = ui.text(String.format(java.util.Locale.ROOT, "%02d  %s", i + 1, labels[i]), 11, i == position ? GOLD : MUTED, i == position);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        }
        ui.add(body, row, 18);
    }
    private void title(String eyebrow, String heading, String description) {
        ui.add(body, ui.label(eyebrow), 24);
        TextView title = ui.text(heading, 29, INK, true); title.setLetterSpacing(-0.035f); title.setLineSpacing(ui.dp(5), 1);
        title.setAccessibilityHeading(true);
        ui.add(body, title, 12);
        if (!description.isEmpty()) ui.add(body, ui.text(description, 14, MUTED, false), 12);
    }
    private LinearLayout card(int padding) {
        LinearLayout v = ui.column(); v.setPadding(ui.dp(padding), ui.dp(padding), ui.dp(padding), ui.dp(padding));
        v.setBackground(ui.shape(CARD, 22, LINE)); return v;
    }
    private void inputPage() {
        step(0);
        title("KEEP WHAT YOU LOVE", "좋아하는 순간을,\n나만의 컬렉션으로.", "YouTube에서 복사한 링크를 넣어주세요.");
        StudioStyle.ArchiveArtwork artwork = new StudioStyle.ArchiveArtwork(this);
        LinearLayout.LayoutParams art = new LinearLayout.LayoutParams(-1, ui.dp(138)); art.topMargin = ui.dp(10); body.addView(artwork, art);
        LinearLayout input = card(18); ui.add(body, input, 12);
        TextView label = ui.text("영상 링크", 13, INK, true); input.addView(label); label.setLabelFor(R.id.video_link);
        url = new EditText(this); url.setId(R.id.video_link); url.setTextSize(15); url.setTextColor(INK);
        url.setHint("눌러서 복사한 링크 붙여넣기"); url.setHintTextColor(MUTED);
        url.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        url.setImeOptions(EditorInfo.IME_ACTION_NEXT); url.setSingleLine(true);
        url.setPadding(ui.dp(12), ui.dp(16), ui.dp(12), ui.dp(16)); url.setBackground(ui.shape(PAPER, 12, 0));
        url.setText(draft); ui.add(input, url, 12);
        inputError = ui.text("", 12, ERROR, false); inputError.setId(R.id.link_error);
        inputError.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE); inputError.setVisibility(View.GONE); ui.add(input, inputError, 8);
        url.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { draft = s.toString(); }
            @Override public void afterTextChanged(Editable e) { inputError.setVisibility(View.GONE); }
        });
        url.setOnEditorActionListener((v, id, event) -> { if (id == EditorInfo.IME_ACTION_NEXT) { validateLink(); return true; } return false; });
        url.setOnClickListener(v -> paste(true));
        Button paste = ui.button("복사한 링크 붙여넣기", false, "paste"); paste.setId(R.id.paste_link);
        ui.add(input, paste, 12); paste.setOnClickListener(v -> paste(false));
        ui.add(body, ui.text("YouTube  ›  공유  ›  링크 복사\n입력란을 누르면 복사한 영상 주소가 들어갑니다.", 12, MUTED, false), 16);
        activeCard();
        action = ui.button("다음 · 형식 선택", true, "arrow"); action.setId(R.id.link_next);
        action.setOnClickListener(v -> validateLink()); footer.addView(action);
        footerNote("링크를 입력한 뒤 저장할 형식을 선택합니다.");
    }
    private void paste(boolean automatic) {
        // Clipboard access is limited to a user tap; never read it on launch, resume or focus.
        try {
            ClipboardManager manager = getSystemService(ClipboardManager.class);
            ClipData data = manager.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) {
                if (!automatic) inputProblem("복사된 링크가 없습니다. YouTube에서 링크를 먼저 복사해 주세요.");
                return;
            }
            ClipData.Item item = data.getItemAt(0);
            CharSequence value = item.getText();
            if (value == null && item.getUri() != null) value = item.getUri().toString();
            String next = YouTubeLink.parse(value == null ? "" : value.toString());
            if (automatic && next.equals(lastAutoClipboard) && !draft.isEmpty()) return;
            lastAutoClipboard = next;
            url.setText(next); url.setSelection(url.length());
            if (!automatic) hideKeyboard();
        } catch (IllegalArgumentException invalid) {
            if (!automatic) inputProblem(invalid.getMessage());
        } catch (SecurityException blocked) {
            if (!automatic) inputProblem("클립보드를 열지 못했습니다. 입력란을 길게 눌러 붙여넣어 주세요.");
        }
    }
    private void validateLink() {
        if (busy()) { tell("다운로드 진행 중", "현재 작업이 끝나거나 취소된 뒤 새 다운로드를 시작할 수 있습니다."); return; }
        try {
            String next = YouTubeLink.parse(draft);
            if (!next.equals(confirmed)) selected = "";
            confirmed = next; draft = next; remember(); hideKeyboard(); show(Page.FORMAT);
        } catch (IllegalArgumentException invalid) { inputProblem(invalid.getMessage()); }
    }
    private void inputProblem(String message) { inputError.setText(message); inputError.setVisibility(View.VISIBLE); }

    private void formatPage() {
        step(1);
        title("CHOOSE YOUR FORMAT", "어떻게 저장할까요?", "");
        LinearLayout link = ui.row(); link.setPadding(ui.dp(14), ui.dp(4), ui.dp(14), ui.dp(4)); link.setBackground(ui.shape(TINT, 12, 0));
        TextView address = ui.text(confirmed.replace("https://www.youtube.com/watch?v=", "youtu.be/"), 12, INK, false);
        address.setSingleLine(true); address.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        link.addView(address, new LinearLayout.LayoutParams(0, -2, 1));
        TextView edit = ui.text("수정", 12, GOLD, true); edit.setPadding(ui.dp(16), ui.dp(8), 0, ui.dp(8)); edit.setMinHeight(ui.dp(48)); edit.setGravity(Gravity.CENTER);
        edit.setMinWidth(ui.dp(48));
        edit.setContentDescription("입력한 링크 수정"); edit.setBackground(ui.touch(Color.TRANSPARENT, 8, 0)); edit.setOnClickListener(v -> show(Page.LINK)); link.addView(edit);
        ui.add(body, link, 16);
        ui.add(body, ui.label("VIDEO  /  영상과 소리"), 16);
        formatChoice("video720", R.id.format_720, "720p", "가볍게 간직하기", "최대 HD", "video");
        formatChoice("video1080", R.id.format_1080, "1080p", "더 선명하게 간직하기", "최대 FHD", "video");
        ui.add(body, ui.label("AUDIO  /  소리만"), 16);
        formatChoice("m4a", R.id.format_m4a, "M4A", "음질과 용량의 균형", "음원", "audio");
        formatChoice("mp3", R.id.format_mp3, "MP3", "다양한 기기에서 듣기", "음원", "audio");
        ui.add(body, ui.text("영상은 원본 화질 안에서 MP4를 우선합니다.\n원본에 따라 MKV 또는 WebM으로 저장될 수 있어요.", 11, MUTED, false), 16);
        LinearLayout options = ui.row();
        qualityButton = ui.button("음원 품질", false, null); qualityButton.setId(R.id.audio_quality);
        qualityButton.setTextSize(12); qualityButton.setOnClickListener(v -> chooseQuality());
        LinearLayout.LayoutParams qualitySize = new LinearLayout.LayoutParams(0, -2, 1); qualitySize.rightMargin = ui.dp(8);
        options.addView(qualityButton, qualitySize);
        folderButton = ui.button("저장 폴더", false, null); folderButton.setId(R.id.save_folder); folderButton.setTextSize(12);
        folderButton.setMaxLines(2); folderButton.setEllipsize(android.text.TextUtils.TruncateAt.END);
        folderButton.setOnClickListener(v -> chooseFolder()); options.addView(folderButton, new LinearLayout.LayoutParams(0, -2, 1));
        footer.addView(options);
        action = ui.button("저장 형식을 선택해 주세요", true, "download"); action.setId(R.id.download_start);
        action.setOnClickListener(v -> startDownload(false)); ui.add(footer, action, 10);
        footerNote("폴더를 선택하면 다음 다운로드에도 적용됩니다.");
        selectFormat(selected);
    }
    private void formatChoice(String mode, int id, String title, String subtitle, String badge, String icon) {
        LinearLayout option = ui.row(); option.setId(id); option.setPadding(ui.dp(16), ui.dp(11), ui.dp(14), ui.dp(11));
        option.setMinimumHeight(ui.dp(72)); option.setClickable(true); option.setFocusable(true);
        option.setContentDescription(SaveRequest.label(mode) + ", " + subtitle);
        TextView glyph = ui.text("", 16, GOLD, false); glyph.setCompoundDrawablesWithIntrinsicBounds(ui.icon(icon, GOLD, 25), null, null, null);
        option.addView(glyph, new LinearLayout.LayoutParams(ui.dp(40), -2));
        LinearLayout description = ui.column();
        LinearLayout heading = ui.row(); heading.addView(ui.text(title, 20, INK, true));
        TextView tag = ui.text(badge, 10, GOLD, true); tag.setPadding(ui.dp(7), ui.dp(4), ui.dp(7), ui.dp(4)); tag.setBackground(ui.shape(TINT, 5, 0));
        LinearLayout.LayoutParams tagSize = new LinearLayout.LayoutParams(-2, -2); tagSize.leftMargin = ui.dp(10); heading.addView(tag, tagSize);
        description.addView(heading); ui.add(description, ui.text(subtitle, 12, MUTED, false), 6);
        option.addView(description, new LinearLayout.LayoutParams(0, -2, 1));
        TextView check = ui.text("", 16, INK, false); check.setGravity(Gravity.CENTER);
        check.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        option.addView(check, new LinearLayout.LayoutParams(ui.dp(26), ui.dp(26)));
        choices.put(mode, option); choiceMarks.put(mode, check); ui.add(body, option, 8);
        option.setOnClickListener(v -> selectFormat(mode));
    }
    private void selectFormat(String mode) {
        selected = SaveRequest.MODES.contains(mode) ? mode : "";
        for (Map.Entry<String, LinearLayout> entry : choices.entrySet()) {
            boolean chosen = entry.getKey().equals(selected);
            LinearLayout view = entry.getValue(); view.setSelected(chosen);
            view.setStateDescription(chosen ? "선택됨" : "선택 안 됨");
            view.setBackground(ui.touch(chosen ? 0xFFF2EBDD : CARD, 17, chosen ? GOLD : LINE));
            TextView mark = choiceMarks.get(entry.getKey());
            mark.setBackground(ui.shape(chosen ? INK : Color.TRANSPARENT, 13, chosen ? 0 : LINE));
            mark.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
            if (chosen) { mark.setCompoundDrawablesWithIntrinsicBounds(ui.icon("check", LIGHT_GOLD, 16), null, null, null); mark.setPadding(ui.dp(5), 0, 0, 0); }
        }
        if (action != null) {
            action.setText(selected.isEmpty() ? "저장 형식을 선택해 주세요" : shortLabel(selected) + " 다운로드");
            setEnabled(action, !selected.isEmpty() && !busy());
        }
        updateOptions();
    }
    private void updateOptions() {
        if (folderButton == null) return;
        SaveDestination.Target target = SaveDestination.selected(this);
        folderButton.setText(getString(R.string.selected_folder, target.label()));
        folderButton.setContentDescription("저장 폴더 변경, 현재 " + target.label());
        boolean audio = AudioQuality.isAudio(selected);
        qualityButton.setVisibility(audio ? View.VISIBLE : View.GONE);
        if (audio) {
            String label = AudioQuality.label(AudioQuality.selected(this, selected));
            qualityButton.setText(getString(R.string.selected_quality, label));
            qualityButton.setContentDescription("음원 품질 변경, 현재 " + label);
        }
        if (footerHint != null) footerHint.setText(audio ? "높은 품질을 골라도 원본보다 음질이 좋아지지는 않아요." : "폴더를 선택하면 다음 다운로드에도 적용됩니다.");
    }
    private void chooseQuality() {
        if (!AudioQuality.isAudio(selected)) return;
        String mode = selected;
        List<String> values = AudioQuality.choices(mode);
        String[] labels = values.stream().map(AudioQuality::label).toArray(String[]::new);
        new AlertDialog.Builder(this).setTitle(mode.toUpperCase(java.util.Locale.ROOT) + " 음원 품질")
                .setSingleChoiceItems(labels, values.indexOf(AudioQuality.selected(this, mode)), (dialog, position) -> {
                    AudioQuality.select(this, mode, values.get(position)); dialog.dismiss(); updateOptions();
                }).setNegativeButton("닫기", null).show();
    }
    private void chooseFolder() {
        new AlertDialog.Builder(this).setTitle("저장 폴더")
                .setItems(new String[]{"폴더 선택…", "기본 폴더 · " + SaveDestination.DEFAULT_LABEL}, (dialog, position) -> {
                    if (position == 1) { SaveDestination.useDefault(this); updateOptions(); return; }
                    Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    SaveDestination.Target current = SaveDestination.selected(this);
                    if (!current.isDefault()) picker.putExtra(DocumentsContract.EXTRA_INITIAL_URI, current.directory());
                    try { startActivityForResult(picker, PICK_FOLDER); }
                    catch (RuntimeException e) { tell("폴더 선택", "휴대폰의 파일 선택 화면을 열 수 없습니다."); }
                }).setNegativeButton("닫기", null).show();
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FOLDER || result != RESULT_OK || data == null) return;
        try { SaveDestination.accept(this, data); updateOptions(); }
        catch (java.io.IOException e) { tell("폴더를 선택하지 못했습니다", e.getMessage()); }
    }
    private String shortLabel(String mode) {
        return switch (mode) { case "video720" -> "720p 영상"; case "video1080" -> "1080p 영상"; case "mp3" -> "MP3 음원"; case "m4a" -> "M4A 음원"; default -> "파일"; };
    }

    private void transferPage() {
        step(2);
        transferTag = ui.label("YOUR PERSONAL ARCHIVE"); ui.add(body, transferTag, 26);
        transferTitle = ui.text("내 폰에\n담고 있어요.", 29, INK, true); transferTitle.setLetterSpacing(-0.035f); ui.add(body, transferTitle, 12);
        LinearLayout card = card(24); card.setGravity(Gravity.CENTER_HORIZONTAL); ui.add(body, card, 28);
        transferSymbol = ui.text("", 28, GOLD, false); transferSymbol.setGravity(Gravity.CENTER);
        transferSymbol.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(20)); transferSymbol.setBackground(ui.shape(TINT, 36, 0));
        transferSymbol.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        card.addView(transferSymbol, new LinearLayout.LayoutParams(ui.dp(72), ui.dp(72)));
        transferMessage = ui.text("", 16, INK, true); transferMessage.setGravity(Gravity.CENTER); ui.add(card, transferMessage, 22);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setProgressTintList(ColorStateList.valueOf(GOLD)); progress.setIndeterminateTintList(ColorStateList.valueOf(GOLD));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(TINT)); ui.add(card, progress, 22);
        transferPercent = ui.text("", 12, MUTED, false); transferPercent.setGravity(Gravity.CENTER); ui.add(card, transferPercent, 10);
        transferDetail = ui.text("", 13, MUTED, false); transferDetail.setTextIsSelectable(true); ui.add(body, transferDetail, 20);
        transferSecondary = ui.button("자세한 내용", false, null); ui.add(body, transferSecondary, 16);
        transferSecondary.setOnClickListener(v -> tell("작업 상세", store.state().detail()));
        action = ui.button("다운로드 취소", false, null); action.setId(R.id.save_cancel); footer.addView(action);
        footerNote("다른 화면으로 이동해도 작업은 계속됩니다.");
    }
    private void startDownload(boolean updateOnly) {
        if (busy()) { show(Page.TRANSFER); return; }
        if (!updateOnly) {
            if (!SaveRequest.MODES.contains(selected)) return;
            try { if (!YouTubeLink.parse(draft).equals(confirmed)) { selected = ""; show(Page.LINK); return; } }
            catch (IllegalArgumentException invalid) { show(Page.LINK); return; }
            try { SaveDestination.validate(this, SaveDestination.selected(this)); }
            catch (java.io.IOException e) { tell("저장 폴더를 확인해 주세요", e.getMessage()); return; }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !getPreferences(0).getBoolean("notificationsAsked", false)) {
            getPreferences(0).edit().putBoolean("notificationsAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
        hideKeyboard(); remember();
        try {
            previousTaskId = store.task().id();
            startForegroundService(new Intent(this, SaveService.class).setAction(updateOnly ? SaveService.UPDATE : SaveService.SAVE)
                    .putExtra("url", updateOnly ? "" : confirmed).putExtra("mode", selected)
                    .putExtra("quality", AudioQuality.selected(this, selected))
                    .putExtra("folderUri", SaveDestination.selected(this).tree()).putExtra("folderLabel", SaveDestination.selected(this).label()));
            starting = true; startUpdate = updateOnly; startedAt = SystemClock.elapsedRealtime(); show(Page.TRANSFER);
        } catch (RuntimeException e) { starting = false; tell("시작하지 못했습니다", "앱을 다시 열고 다운로드를 시도해 주세요."); }
    }
    private boolean busy() { return starting || SaveService.running || store.state().busy(); }
    private void renderState() {
        SaveStore.State state = store.state();
        if (starting && (SaveService.running || state.busy() || !previousTaskId.equals(store.task().id()))) starting = false;
        if (starting && SystemClock.elapsedRealtime() - startedAt > 15000) {
            starting = false;
            // Do not overwrite service state; it may be a delayed start. Keep the draft for retry.
            tell("시작이 지연되고 있습니다", "작업 상태를 확인한 뒤 다시 시도해 주세요.");
        }
        boolean busy = busy();
        if (page == Page.LINK) {
            setEnabled(action, !busy);
            activeBanner.setVisibility(busy ? View.VISIBLE : View.GONE);
            activeText.setText(starting ? "다운로드 시작 중 · 상태 보기" : "작업 진행 중 · 상태 보기");
        } else if (page == Page.FORMAT) setEnabled(action, !busy && !selected.isEmpty());
        else if (page == Page.TRANSFER) renderTransfer(state, busy);
        else if (page == Page.LIBRARY) {
            List<SaveStore.Item> items = store.items();
            if (!renderedItems.equals(items.toString())) { renderedItems = items.toString(); renderItems(items); }
            activeBanner.setVisibility(busy ? View.VISIBLE : View.GONE);
        }
    }
    private void renderTransfer(SaveStore.State state, boolean busy) {
        String phase = busy ? "running" : state.phase();
        SaveStore.Task task = store.task();
        boolean updating = starting ? startUpdate : task.updateOnly();
        if (!phase.equals(renderedPhase)) {
            renderedPhase = phase;
            completion = !busy && phase.equals("done") && !updating && !store.items().isEmpty() ? store.items().get(0) : null;
            String icon = busy ? "download" : phase.equals("done") ? "check" : phase.equals("failed") ? "error" : "archive";
            transferSymbol.setCompoundDrawablesWithIntrinsicBounds(ui.icon(icon, phase.equals("failed") ? ERROR : GOLD, 32), null, null, null);
            transferTitle.setText(busy ? (updating ? "더 편리하게\n준비하고 있어요." : "내 폰에\n담고 있어요.")
                    : phase.equals("done") ? (updating ? "최신 상태로\n준비됐어요." : "나만의 컬렉션에\n담았어요.")
                    : phase.equals("failed") ? "잠시, 확인이\n필요해요." : "다운로드를\n멈췄어요.");
            action.setText(busy ? "작업 취소" : completion != null ? "저장한 파일 열기" : "링크 입력으로 돌아가기");
            setEnabled(action, true);
            action.setOnClickListener(v -> {
                if (busy()) {
                    startService(new Intent(this, SaveService.class).setAction(SaveService.CANCEL));
                    setEnabled(action, false);
                } else if (completion != null) open(completion, false);
                else show(Page.LINK);
            });
            footerHint.setText(busy ? "다른 화면으로 이동해도 작업은 계속됩니다." : updating ? "다운로드 기능 업데이트" : "저장 위치  ·  " + task.folder());
        }
        transferTag.setText(updating ? "DOWNLOAD SUPPORT" : SaveRequest.MODES.contains(task.mode()) ? SaveRequest.label(task.mode()) : "YOUR PERSONAL ARCHIVE");
        if (!updating && AudioQuality.isAudio(task.mode()) && !task.quality().isEmpty()) transferTag.append("  ·  " + AudioQuality.label(task.quality()));
        transferMessage.setText(starting ? "다운로드를 준비하고 있습니다…" : state.message());
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        progress.setIndeterminate(state.progress() < 0 || starting); progress.setProgress(Math.max(0, state.progress()));
        transferPercent.setVisibility(busy ? View.VISIBLE : View.GONE);
        transferPercent.setText(state.progress() < 0 || starting ? "잠시만 기다려 주세요" : getString(R.string.current_progress, state.progress()));
        transferDetail.setText(phase.equals("done") ? state.detail() : busy ? "완성된 파일은 보관함에서 바로 열거나 공유할 수 있어요."
                : phase.equals("cancelled") ? "원할 때 같은 링크로 다시 시작할 수 있어요."
                : "네트워크 연결과 링크를 확인해 주세요. 자세한 내용에서 오류 정보를 볼 수 있습니다.");
        transferSecondary.setVisibility(phase.equals("failed") && !state.detail().isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void libraryPage() {
        title("MY COLLECTION", "보관함", "내가 고른 영상과 소리를 한곳에.");
        libraryCount = ui.text("", 12, GOLD, true); ui.add(body, libraryCount, 20);
        activeCard(); recent = ui.column(); ui.add(body, recent, 14);
        Button folder = ui.button("저장 폴더 열기", false, "folder"); footer.addView(folder);
        folder.setOnClickListener(v -> {
            SaveDestination.Target destination = SaveDestination.selected(this);
            try {
                startActivity(destination.isDefault() ? new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)
                        : new Intent(Intent.ACTION_VIEW).setDataAndType(destination.directory(), DocumentsContract.Document.MIME_TYPE_DIR)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
            } catch (RuntimeException e) { tell("저장 위치", "삼성 ‘내 파일’에서 " + destination.label() + " 폴더를 확인해 주세요."); }
        });
        footerNote("파일은 다운로드할 때 선택했던 폴더에 보관됩니다.");
    }
    private void renderItems(List<SaveStore.Item> items) {
        libraryCount.setText(getString(R.string.library_count, items.size())); recent.removeAllViews();
        if (items.isEmpty()) {
            LinearLayout empty = card(24); empty.setGravity(Gravity.CENTER_HORIZONTAL);
            StudioStyle.ArchiveArtwork art = new StudioStyle.ArchiveArtwork(this); empty.addView(art, new LinearLayout.LayoutParams(-1, ui.dp(140)));
            TextView title = ui.text("첫 번째 컬렉션을 기다려요", 18, INK, true); title.setGravity(Gravity.CENTER); ui.add(empty, title, 16);
            TextView desc = ui.text("마음에 드는 영상의 링크를 복사하고\n새로 저장에서 시작해 보세요.", 13, MUTED, false); desc.setGravity(Gravity.CENTER); ui.add(empty, desc, 12);
            ui.add(recent, empty, 0); return;
        }
        for (SaveStore.Item item : items) {
            LinearLayout card = card(18); ui.add(recent, card, 10);
            TextView meta = ui.label((item.mime().startsWith("audio") ? "AUDIO" : "VIDEO") + "  ·  "
                    + DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(item.time())));
            card.addView(meta);
            TextView filename = ui.text(item.name(), 16, INK, true); filename.setMaxLines(3); filename.setEllipsize(android.text.TextUtils.TruncateAt.END); ui.add(card, filename, 12);
            LinearLayout buttons = ui.row(); ui.add(card, buttons, 16);
            Button open = ui.button("열기", false, "arrow"), share = ui.button("공유", false, "share");
            LinearLayout.LayoutParams first = new LinearLayout.LayoutParams(0, -2, 1); first.rightMargin = ui.dp(8);
            buttons.addView(open, first); buttons.addView(share, new LinearLayout.LayoutParams(0, -2, 1));
            open.setOnClickListener(v -> open(item, false)); share.setOnClickListener(v -> open(item, true));
        }
    }
    private void activeCard() {
        activeBanner = ui.row(); activeBanner.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14));
        activeBanner.setBackground(ui.touch(TINT, 13, 0)); activeBanner.setMinimumHeight(ui.dp(52));
        activeText = ui.text("작업 진행 중 · 상태 보기", 13, INK, true); activeBanner.addView(activeText);
        activeBanner.setOnClickListener(v -> show(Page.TRANSFER)); ui.add(body, activeBanner, 16);
        activeBanner.setVisibility(View.GONE);
    }
    private void bottomNavigation() {
        View divider = new View(this); divider.setBackgroundColor(LINE); root.addView(divider, new LinearLayout.LayoutParams(-1, ui.dp(1)));
        LinearLayout nav = ui.row(); nav.setPadding(ui.dp(20), ui.dp(6), ui.dp(20), ui.dp(6));
        for (boolean collection : new boolean[]{false, true}) {
            TextView tab = ui.text(collection ? "보관함" : "새로 저장", 11, (page == Page.LIBRARY) == collection ? INK : MUTED, true);
            tab.setId(collection ? R.id.nav_library : R.id.nav_new); tab.setGravity(Gravity.CENTER);
            tab.setCompoundDrawablesWithIntrinsicBounds(null, ui.icon(collection ? "archive" : "plus", (page == Page.LIBRARY) == collection ? GOLD : MUTED, 22), null, null);
            tab.setCompoundDrawablePadding(ui.dp(4)); tab.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6));
            tab.setBackground(ui.touch(Color.TRANSPARENT, 12, 0)); tab.setSelected((page == Page.LIBRARY) == collection);
            tab.setOnClickListener(v -> { hideKeyboard(); show(collection ? Page.LIBRARY : Page.LINK); });
            nav.addView(tab, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(nav);
    }
    private void footerNote(String message) {
        footerHint = ui.text(message, 10, MUTED, false); footerHint.setGravity(Gravity.CENTER); ui.add(footer, footerHint, 10);
    }
    private void setEnabled(View view, boolean enabled) { if (view != null) { view.setEnabled(enabled); view.setAlpha(enabled ? 1 : 0.43f); } }
    private void hideKeyboard() { if (root != null) getSystemService(InputMethodManager.class).hideSoftInputFromWindow(root.getWindowToken(), 0); }
    private void tell(String title, String message) { new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("확인", null).show(); }
    private void settings() {
        String name = getString(R.string.app_name) + " 0.3.0";
        new AlertDialog.Builder(this).setTitle(name)
                .setItems(new String[]{"사용 방법", "저장 폴더 변경", "다운로드 기능 업데이트", "앱 정보 · 오픈소스"}, (d, which) -> {
                    if (which == 0) tell("링크로 간편하게 저장하기", "1. YouTube에서 공유 → 링크 복사를 누르세요.\n2. 이 앱의 링크 입력란을 누른 뒤 다음으로 이동하세요.\n3. 영상 또는 음원 형식을 선택하세요. 음원은 품질도 고를 수 있습니다.\n4. 저장 폴더를 확인하고 다운로드하세요.\n\n완성된 파일은 보관함과 선택한 폴더에 저장됩니다. 기본 위치는 다운로드/MoaSave입니다. Android에서 선택할 수 없는 폴더는 그 안에 하위 폴더를 만들어 선택하세요.\n\nM4A 원본 우선은 제공되는 M4A를 우선 보존하고, 없으면 변환합니다. 숫자로 표시된 품질은 인코딩 목표 비트레이트입니다. 원본보다 높게 선택해도 없던 음질이 복원되지는 않습니다.");
                    else if (which == 1) chooseFolder();
                    else if (which == 2) startDownload(true);
                    else tell(name, getString(R.string.engine_version, EngineUpdater.version(this))
                            + "\n\n로그인·멤버십·보호된 영상과 진행 중 생방송은 지원하지 않습니다. 저장 권한이 있는 콘텐츠에 사용해 주세요. YouTube 변경으로 일부 링크가 실패할 수 있습니다."
                            + "\n\n공식 GitHub의 다운로드 기능 업데이트를 첫 저장 및 하루 간격으로 확인합니다. 별도 서버로 링크나 파일을 업로드하지 않으며 YouTube와 GitHub에 직접 연결합니다."
                            + "\n\nyoutubedl-android 0.18.1 · GPL-3.0\nyt-dlp · Unlicense 및 구성요소별 라이선스\nFFmpeg · LGPL/GPL\nPython · PSF\nQuickJS · MIT\n\n앱 소스와 라이선스는 APK와 함께 제공한 소스 파일에 있습니다.");
                }).setNegativeButton("닫기", null).show();
    }
    private void open(SaveStore.Item item, boolean share) {
        Uri uri = Uri.parse(item.uri());
        try {
            try (android.os.ParcelFileDescriptor descriptor = getContentResolver().openFileDescriptor(uri, "r")) {
                if (descriptor == null) throw new java.io.IOException("missing");
            }
            Intent intent = share ? new Intent(Intent.ACTION_SEND).setType(item.mime()).putExtra(Intent.EXTRA_STREAM, uri)
                    : new Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime());
            intent.setClipData(ClipData.newRawUri("저장한 파일", uri)); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, share ? "파일 공유" : "파일 열기"));
        } catch (Exception e) { tell("파일을 열 수 없습니다", "파일이 이동·삭제되었거나 재생할 앱이 없습니다. 내 파일에서 확인해 주세요."); }
    }
}
