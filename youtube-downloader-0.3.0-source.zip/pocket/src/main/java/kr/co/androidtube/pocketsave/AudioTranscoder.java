package kr.co.androidtube.pocketsave;

import android.content.Context;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

final class AudioTranscoder {
    // yt-dlp copies an existing AAC/M4A stream even when --audio-quality was supplied.
    // Explicit M4A bitrates therefore require a separate, cancellable encoding pass.
    static List<String> command(String executable, File input, File output, String quality) {
        String rate = AudioQuality.validate("m4a", quality);
        if (rate.equals("original")) throw new IllegalArgumentException("원본 우선은 재인코딩하지 않습니다.");
        return List.of(executable, "-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", input.getAbsolutePath(),
                "-map", "0:a:0", "-vn", "-c:a", "aac", "-b:a", rate + "k", "-movflags", "+faststart", output.getAbsolutePath());
    }
    static File convert(Context context, File input, String quality, BooleanSupplier cancelled) throws IOException, InterruptedException {
        if (cancelled.getAsBoolean()) throw new CancellationException();
        File output = new File(input.getParentFile(), "media.encoded.m4a");
        File log = new File(input.getParentFile(), "audio-conversion.log");
        File nativeDir = new File(context.getApplicationInfo().nativeLibraryDir);
        File packages = new File(context.getNoBackupFilesDir(), "youtubedl-android/packages");
        ProcessBuilder builder = new ProcessBuilder(command(new File(nativeDir, "libffmpeg.so").getAbsolutePath(), input, output, quality));
        builder.environment().put("LD_LIBRARY_PATH", new File(packages, "python/usr/lib").getAbsolutePath()
                + ":" + new File(packages, "ffmpeg/usr/lib").getAbsolutePath() + ":" + nativeDir.getAbsolutePath());
        builder.environment().put("TMPDIR", context.getCacheDir().getAbsolutePath());
        builder.redirectErrorStream(true).redirectOutput(log);
        Process process = builder.start();
        boolean complete = false;
        try {
            while (!process.waitFor(250, TimeUnit.MILLISECONDS)) {
                if (cancelled.getAsBoolean()) throw new CancellationException();
            }
            if (cancelled.getAsBoolean()) throw new CancellationException();
            if (process.exitValue() != 0 || !output.isFile() || output.length() == 0)
                throw new IOException("선택한 음원 품질로 변환하지 못했습니다. 다른 품질로 다시 시도해 주세요.");
            complete = true;
            return output;
        } finally {
            if (process.isAlive()) process.destroyForcibly();
            if (!complete) output.delete();
        }
    }
}
