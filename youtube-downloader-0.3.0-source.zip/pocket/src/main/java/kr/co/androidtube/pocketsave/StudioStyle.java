package kr.co.androidtube.pocketsave;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared visual language for the phone UI; no downloaded fonts or artwork. */
final class StudioStyle {
    static final int PAPER = Color.rgb(246, 243, 237), INK = Color.rgb(32, 40, 36);
    static final int MUTED = Color.rgb(105, 108, 101), GOLD = Color.rgb(138, 106, 54);
    static final int LINE = Color.rgb(222, 215, 202), CARD = Color.rgb(255, 253, 249);
    static final int TINT = Color.rgb(236, 230, 217), LIGHT_GOLD = Color.rgb(215, 190, 139);
    static final int ERROR = Color.rgb(157, 59, 45);
    final Context context;
    StudioStyle(Context context) { this.context = context; }
    int dp(float value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }
    LinearLayout column() { LinearLayout v = new LinearLayout(context); v.setOrientation(LinearLayout.VERTICAL); return v; }
    LinearLayout row() { LinearLayout v = new LinearLayout(context); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    TextView text(String value, float size, int color, boolean medium) {
        TextView v = new TextView(context); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        v.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        v.setIncludeFontPadding(false); v.setLineSpacing(dp(4), 1); return v;
    }
    TextView label(String value) {
        TextView v = text(value, 11, GOLD, true); v.setLetterSpacing(0.13f); return v;
    }
    GradientDrawable shape(int color, float radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    Drawable touch(int color, float radius, int stroke) {
        return new RippleDrawable(ColorStateList.valueOf(0x188A6A36), shape(color, radius, stroke), shape(Color.WHITE, radius, 0));
    }
    Button button(String value, boolean primary, String symbol) {
        Button b = new Button(context); b.setText(value); b.setAllCaps(false); b.setTextSize(15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setMinHeight(dp(54)); b.setMinimumHeight(dp(54)); b.setMinimumWidth(0); b.setMinWidth(0);
        b.setPadding(dp(18), dp(14), dp(18), dp(14)); b.setStateListAnimator(null);
        b.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled}, new int[]{}},
                new int[]{primary ? 0xFFB5B5AC : MUTED, primary ? CARD : INK}));
        b.setBackground(touch(primary ? INK : CARD, 16, primary ? 0 : LINE));
        if (symbol != null) {
            b.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, icon(symbol, primary ? LIGHT_GOLD : GOLD, 19), null);
            b.setCompoundDrawablePadding(dp(12));
        }
        return b;
    }
    TextView iconButton(String symbol, String description) {
        TextView b = text("", 14, INK, false); b.setGravity(Gravity.CENTER);
        b.setBackground(touch(Color.TRANSPARENT, 24, 0));
        b.setCompoundDrawablesRelativeWithIntrinsicBounds(icon(symbol, INK, 22), null, null, null);
        b.setPadding(dp(13), dp(13), dp(13), dp(13)); b.setContentDescription(description);
        b.setClickable(true); b.setFocusable(true); b.setMinHeight(dp(48)); b.setMinWidth(dp(48)); return b;
    }
    void add(LinearLayout parent, View child, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); parent.addView(child, p);
    }
    void line(LinearLayout parent, int margin) {
        View v = new View(context); v.setBackgroundColor(LINE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1)); p.topMargin = dp(margin); p.bottomMargin = dp(margin);
        parent.addView(v, p);
    }
    Icon icon(String name, int color, int size) { return new Icon(name, color, dp(size)); }

    static final class Icon extends Drawable {
        private final String name; private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final int size;
        Icon(String name, int color, int size) { this.name = name; this.size = size; paint.setColor(color); }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void draw(Canvas canvas) {
            canvas.save(); canvas.translate(getBounds().left, getBounds().top);
            canvas.scale(getBounds().width() / 24f, getBounds().height() / 24f);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.6f);
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
            switch (name) {
                case "arrow" -> { segment(canvas, 4, 12, 19, 12); path(canvas, 13, 6, 19, 12, 13, 18); }
                case "back" -> { segment(canvas, 20, 12, 5, 12); path(canvas, 11, 6, 5, 12, 11, 18); }
                case "download" -> { segment(canvas, 12, 3, 12, 15); path(canvas, 7, 10, 12, 15, 17, 10); path(canvas, 4, 16, 4, 21, 20, 21, 20, 16); }
                case "check" -> path(canvas, 5, 12, 10, 17, 19, 7);
                case "video" -> { canvas.drawRoundRect(3, 4, 21, 20, 3, 3, paint); path(canvas, 10, 8, 16, 12, 10, 16, 10, 8); }
                case "audio" -> { path(canvas, 10, 17, 10, 5, 20, 3, 20, 15); canvas.drawOval(4, 15, 10, 20, paint); canvas.drawOval(14, 13, 20, 18, paint); }
                case "link" -> { canvas.save(); canvas.rotate(-38, 12, 12); canvas.drawRoundRect(2, 8, 14, 16, 4, 4, paint); canvas.drawRoundRect(10, 8, 22, 16, 4, 4, paint); canvas.restore(); }
                case "paste" -> { canvas.drawRoundRect(5, 5, 19, 22, 2, 2, paint); canvas.drawRoundRect(8, 2, 16, 7, 2, 2, paint); segment(canvas, 9, 12, 15, 12); segment(canvas, 9, 16, 15, 16); }
                case "folder" -> { path(canvas, 3, 8, 3, 5, 10, 5, 12, 8, 21, 8, 21, 20, 3, 20, 3, 8); }
                case "archive" -> { canvas.drawRoundRect(3, 8, 21, 21, 2, 2, paint); path(canvas, 3, 8, 5, 3, 19, 3, 21, 8); segment(canvas, 9, 13, 15, 13); }
                case "plus" -> { segment(canvas, 5, 12, 19, 12); segment(canvas, 12, 5, 12, 19); }
                case "edit" -> { path(canvas, 4, 17, 4, 21, 8, 21, 21, 8, 17, 4, 4, 17); segment(canvas, 14, 7, 18, 11); }
                case "settings" -> { segment(canvas, 4, 6, 20, 6); segment(canvas, 4, 12, 20, 12); segment(canvas, 4, 18, 20, 18); circle(canvas, 9, 6); circle(canvas, 16, 12); circle(canvas, 8, 18); }
                case "share" -> { path(canvas, 6, 14, 6, 21, 20, 21, 20, 14); segment(canvas, 13, 15, 13, 3); path(canvas, 8, 8, 13, 3, 18, 8); }
                case "error" -> { canvas.drawCircle(12, 12, 9, paint); segment(canvas, 12, 7, 12, 13); segment(canvas, 12, 17, 12, 17.1f); }
                default -> canvas.drawCircle(12, 12, 8, paint);
            }
            canvas.restore();
        }
        private void circle(Canvas c, float x, float y) {
            int color = paint.getColor(); paint.setStyle(Paint.Style.FILL); paint.setColor(PAPER); c.drawCircle(x, y, 2.3f, paint);
            paint.setColor(color); paint.setStyle(Paint.Style.STROKE); c.drawCircle(x, y, 2.3f, paint);
        }
        private void segment(Canvas c, float x, float y, float a, float b) { c.drawLine(x, y, a, b, paint); }
        private void path(Canvas c, float... p) {
            path.reset(); path.moveTo(p[0], p[1]); for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]); c.drawPath(path, paint);
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Small vector artwork, kept decorative so it doesn't duplicate accessible instructions. */
    static final class ArchiveArtwork extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path play = new Path();
        private final Icon download = new Icon("download", INK, 24);
        private static final float[] WAVE = {8, 18, 26, 12, 22, 8};
        ArchiveArtwork(Context c) {
            super(c); setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
            play.moveTo(156, 60); play.lineTo(183, 78); play.lineTo(156, 96); play.close();
            download.setBounds(254, 27, 276, 49);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); c.save();
            float scale = Math.min(getWidth() / 320f, getHeight() / 152f);
            c.translate((getWidth() - 320 * scale) / 2, (getHeight() - 152 * scale) / 2); c.scale(scale, scale);
            p.setColor(0xFFEDE7DC); c.drawOval(26, 19, 296, 144, p);
            c.save(); c.rotate(-9, 144, 78); p.setColor(0xFFD7C8AD); c.drawRoundRect(75, 13, 242, 119, 12, 12, p); c.restore();
            c.save(); c.rotate(6, 162, 82); p.setColor(INK); c.drawRoundRect(82, 24, 257, 134, 12, 12, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(0xFF697267); c.drawRoundRect(92, 34, 247, 124, 7, 7, p);
            p.setStyle(Paint.Style.FILL); p.setColor(LIGHT_GOLD); c.drawPath(play, p); c.restore();
            p.setColor(CARD); c.drawRoundRect(39, 93, 116, 138, 12, 12, p);
            p.setColor(GOLD);
            for (int i = 0; i < WAVE.length; i++) c.drawRoundRect(52 + i * 8, 116 - WAVE[i] / 2, 55 + i * 8, 116 + WAVE[i] / 2, 1.5f, 1.5f, p);
            p.setColor(LIGHT_GOLD); c.drawCircle(265, 38, 19, p);
            download.draw(c);
            c.restore();
        }
    }
}
