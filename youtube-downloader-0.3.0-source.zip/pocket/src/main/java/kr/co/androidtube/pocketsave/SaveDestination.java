package kr.co.androidtube.pocketsave;

import android.content.Context;
import android.content.Intent;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.IOException;

final class SaveDestination {
    static final String DEFAULT_LABEL = "다운로드 / MoaSave";
    record Target(String tree, String label) {
        boolean isDefault() { return tree.isEmpty(); }
        Uri directory() {
            Uri uri = Uri.parse(tree);
            return DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri));
        }
    }
    static Target selected(Context context) {
        var preferences = context.getSharedPreferences("download_settings", 0);
        String uri = preferences.getString("folder_uri", "");
        return new Target(uri, uri.isEmpty() ? DEFAULT_LABEL : preferences.getString("folder_name", "선택한 폴더"));
    }
    static void useDefault(Context context) {
        // Keep old tree grants: earlier library entries can still need them.
        context.getSharedPreferences("download_settings", 0).edit().remove("folder_uri").remove("folder_name").apply();
    }
    static boolean hasPermission(Context context, Uri uri) {
        for (UriPermission permission : context.getContentResolver().getPersistedUriPermissions()) {
            if (permission.getUri().equals(uri) && permission.isReadPermission() && permission.isWritePermission()) return true;
        }
        return false;
    }
    static void validate(Context context, Target target) throws IOException {
        if (target.isDefault()) return;
        try {
            Uri uri = Uri.parse(target.tree());
            if (!DocumentsContract.isTreeUri(uri) || !hasPermission(context, uri))
                throw new IOException("저장 폴더 권한이 없습니다. 저장 폴더를 다시 선택해 주세요.");
            folderName(context, target.directory());
        } catch (SecurityException | IllegalArgumentException e) {
            throw new IOException("저장 폴더를 열 수 없습니다. 저장 폴더를 다시 선택해 주세요.", e);
        }
    }
    private static String folderName(Context context, Uri document) throws IOException {
        try (Cursor cursor = context.getContentResolver().query(document, new String[]{
                DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_FLAGS}, null, null)) {
            if (cursor == null || !cursor.moveToFirst()
                    || !DocumentsContract.Document.MIME_TYPE_DIR.equals(cursor.getString(1))
                    || (cursor.getInt(2) & DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE) == 0)
                throw new IOException("이 저장 폴더에는 파일을 만들 수 없습니다. 다른 폴더를 선택해 주세요.");
            String name = cursor.getString(0);
            return name == null || name.isEmpty() ? "선택한 폴더" : name;
        }
    }
    static void accept(Context context, Intent result) throws IOException {
        Uri uri = result.getData();
        if (uri == null || !"content".equals(uri.getScheme()) || !DocumentsContract.isTreeUri(uri))
            throw new IOException("저장 폴더를 다시 선택해 주세요.");
        int wanted = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        if ((result.getFlags() & wanted) != wanted) throw new IOException("저장 폴더의 읽기·쓰기 권한이 필요합니다.");
        boolean alreadyHeld = hasPermission(context, uri);
        boolean accepted = false;
        try {
            context.getContentResolver().takePersistableUriPermission(uri, wanted);
            Target candidate = new Target(uri.toString(), "");
            validate(context, candidate);
            String name = folderName(context, candidate.directory());
            context.getSharedPreferences("download_settings", 0).edit().putString("folder_uri", uri.toString()).putString("folder_name", name).apply();
            accepted = true;
        } catch (RuntimeException e) {
            throw new IOException("저장 폴더 권한을 유지할 수 없습니다. 다른 폴더를 선택해 주세요.", e);
        } finally {
            if (!accepted && !alreadyHeld) {
                try { context.getContentResolver().releasePersistableUriPermission(uri, wanted); }
                catch (RuntimeException ignored) { }
            }
        }
    }
}
