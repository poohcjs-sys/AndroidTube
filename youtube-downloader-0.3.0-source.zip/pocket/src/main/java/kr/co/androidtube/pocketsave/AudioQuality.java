package kr.co.androidtube.pocketsave;

import android.content.Context;
import java.util.List;

/** Encoding targets, not a promise that a source contains this much audio detail. */
final class AudioQuality {
    static boolean isAudio(String mode) { return "mp3".equals(mode) || "m4a".equals(mode); }
    static List<String> choices(String mode) {
        return switch (mode) {
            case "mp3" -> List.of("128", "192", "256", "320");
            case "m4a" -> List.of("original", "128", "192", "256");
            default -> List.of();
        };
    }
    static String defaultValue(String mode) { return "mp3".equals(mode) ? "192" : "m4a".equals(mode) ? "original" : ""; }
    static String validate(String mode, String value) {
        if (!isAudio(mode)) return "";
        if (value == null || value.isEmpty()) return defaultValue(mode);
        if (!choices(mode).contains(value)) throw new IllegalArgumentException("음원 품질을 다시 선택해 주세요.");
        return value;
    }
    static String label(String value) { return "original".equals(value) ? "원본 우선" : value + " kbps"; }
    static String selected(Context context, String mode) {
        try { return validate(mode, context.getSharedPreferences("download_settings", 0).getString("quality_" + mode, null)); }
        catch (IllegalArgumentException invalid) { return defaultValue(mode); }
    }
    static void select(Context context, String mode, String value) {
        context.getSharedPreferences("download_settings", 0).edit().putString("quality_" + mode, validate(mode, value)).apply();
    }
}
