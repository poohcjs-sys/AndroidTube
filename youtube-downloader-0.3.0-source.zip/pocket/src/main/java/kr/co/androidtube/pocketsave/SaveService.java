package kr.co.androidtube.pocketsave;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.StatFs;
import com.yausername.ffmpeg.FFmpeg;
import com.yausername.youtubedl_android.YoutubeDL;
import kotlin.Unit;
import java.io.File;
import java.nio.file.Files;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class SaveService extends Service {
    static final String SAVE = "save", UPDATE = "update", CANCEL = "cancel";
    private static final String CHANNEL = "download";
    private static final int NOTIFICATION = 41;
    static volatile boolean running;
    private final ScheduledExecutorService worker = Executors.newSingleThreadScheduledExecutor();
    private final ScheduledExecutorService canceller = Executors.newSingleThreadScheduledExecutor();
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final Object jobLock = new Object();
    private String jobId;
    private SaveStore store;
    private PowerManager.WakeLock wakeLock;
    private volatile boolean abandoned;
    private volatile boolean finished;
    private long lastProgress;

    @Override public void onCreate() {
        super.onCreate();
        store = new SaveStore(this);
        getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CHANNEL, "파일 저장 진행", NotificationManager.IMPORTANCE_LOW));
    }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        String action = intent.getAction();
        if (CANCEL.equals(action)) {
            if (running && !finished) {
                cancelled.set(true);
                state("running", "취소하고 있습니다…", -1, "");
            } else stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        if (!SAVE.equals(action) && !UPDATE.equals(action)) { stopSelf(); return START_NOT_STICKY; }
        final String link;
        final String mode = intent.getStringExtra("mode");
        final String quality;
        SaveDestination.Target current = SaveDestination.selected(this);
        final SaveDestination.Target destination = new SaveDestination.Target(
                intent.hasExtra("folderUri") ? intent.getStringExtra("folderUri") : current.tree(),
                intent.hasExtra("folderLabel") ? intent.getStringExtra("folderLabel") : current.label());
        try {
            link = UPDATE.equals(action) ? "" : YouTubeLink.parse(intent.getStringExtra("url"));
            if (SAVE.equals(action) && !SaveRequest.MODES.contains(mode)) throw new IllegalArgumentException("저장 형식을 선택해 주세요.");
            quality = UPDATE.equals(action) ? "" : AudioQuality.validate(mode, intent.getStringExtra("quality"));
        } catch (RuntimeException invalid) {
            store.state("failed", "링크를 확인해 주세요.", -1, invalid.getMessage());
            stopSelf(); return START_NOT_STICKY;
        }
        running = true;
        store.task(link, mode, UPDATE.equals(action), quality, destination.label());
        jobId = UUID.randomUUID().toString();
        try {
            startForeground(NOTIFICATION, notification("저장을 준비하고 있습니다…", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            wakeLock = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MoaSave:download");
            wakeLock.acquire(TimeUnit.HOURS.toMillis(6));
        } catch (RuntimeException blocked) {
            running = false;
            store.state("failed", "앱을 연 상태에서 다시 시작해 주세요.", -1, clean(blocked.getMessage()));
            stopSelf(); return START_NOT_STICKY;
        }
        state("running", "저장을 준비하고 있습니다…", -1, "");
        // Repeated cancellation also covers a cancel arriving just before execute registers its process.
        canceller.scheduleWithFixedDelay(() -> {
            if (cancelled.get() && !finished) {
                try { YoutubeDL.getInstance().destroyProcessById(jobId); } catch (RuntimeException ignored) { }
            }
        }, 0, 400, TimeUnit.MILLISECONDS);
        worker.execute(() -> execute(link, mode, quality, destination, UPDATE.equals(action)));
        return START_NOT_STICKY;
    }

    private void execute(String link, String mode, String quality, SaveDestination.Target destination, boolean updateOnly) {
        File jobs = new File(getCacheDir(), "save-jobs");
        File directory = new File(jobs, jobId);
        try {
            MediaPublisher.recover(this);
            MediaPublisher.removeTree(jobs);
            if (!directory.mkdirs()) throw new java.io.IOException("임시 저장 공간을 만들지 못했습니다.");
            if (new StatFs(getCacheDir().getAbsolutePath()).getAvailableBytes() < 250L * 1024 * 1024)
                throw new java.io.IOException("저장 공간이 부족합니다. 여유 공간을 확보한 뒤 다시 시도해 주세요.");
            checkCancelled();
            if (!updateOnly) SaveDestination.validate(this, destination);
            // Some transitive FFmpeg libraries in 0.18.1 still use 4 KB ELF alignment.
            // Fail explicitly instead of reporting a misleading network/download error on 16 KB devices.
            if (!updateOnly && android.system.Os.sysconf(android.system.OsConstants._SC_PAGESIZE) > 4096)
                throw new java.io.IOException("16 KB 메모리 페이지 기기에는 이 버전의 변환 엔진이 호환되지 않습니다.");
            state("running", "첫 실행을 준비하고 있습니다…", -1, "");
            YoutubeDL.getInstance().init(this);
            FFmpeg.getInstance().init(this);
            checkCancelled();
            if (updateOnly || EngineUpdater.due(this)) {
                state("running", "다운로드 기능을 최신 상태로 확인하고 있습니다…", -1, "");
                try { EngineUpdater.update(this, cancelled::get); }
                catch (CancellationException e) { throw e; }
                catch (Exception e) {
                    if (updateOnly) throw e;
                    state("running", "업데이트에 연결하지 못해 현재 버전으로 시도합니다…", -1, "");
                }
            }
            checkCancelled();
            if (updateOnly) {
                state("done", "다운로드 기능이 최신 상태입니다.", 100, "버전: " + EngineUpdater.version(this));
                return;
            }
            state("running", SaveRequest.label(mode) + " · 영상 정보를 확인하고 있습니다…", -1, "");
            YoutubeDL.getInstance().execute(SaveRequest.create(link, mode, quality, directory), jobId, false,
                    (progress, seconds, line) -> {
                        if (cancelled.get()) return Unit.INSTANCE;
                        long now = android.os.SystemClock.elapsedRealtime();
                        if (now - lastProgress < 800) return Unit.INSTANCE;
                        lastProgress = now;
                        int percent = progress == null || !Float.isFinite(progress) ? -1 : Math.max(0, Math.min(100, progress.intValue()));
                        String message = percent >= 100 ? "파일을 합치거나 음원을 변환하고 있습니다…"
                                : SaveRequest.label(mode) + " · 내려받는 중";
                        state("running", message, percent, "");
                        return Unit.INSTANCE;
                    });
            checkCancelled();
            File result = MediaPublisher.result(directory);
            if ("m4a".equals(mode) && !"original".equals(quality)) {
                state("running", "M4A · " + AudioQuality.label(quality) + "로 변환하고 있습니다…", -1, "");
                result = AudioTranscoder.convert(this, result, quality, cancelled::get);
            }
            String title = new File(directory, "title.txt").isFile()
                    ? new String(Files.readAllBytes(new File(directory, "title.txt").toPath()), java.nio.charset.StandardCharsets.UTF_8).trim() : "YouTube 영상";
            state("running", destination.label() + "에 저장하고 있습니다…", -1, "");
            // Cancellation before publication leaves no visible partial file; commit is the completion point.
            SaveStore.Item item = destination.isDefault()
                    ? MediaPublisher.publish(this, result, title, jobId.substring(0, 8), cancelled::get)
                    : DocumentPublisher.publish(this, destination, result, title, jobId.substring(0, 8), cancelled::get);
            synchronized (jobLock) {
                finished = true;
                store.add(item);
                state("done", "저장 완료 · " + destination.label(), 100, item.name());
            }
        } catch (Exception e) {
            if (!abandoned) {
                if (cancelled.get() || e instanceof CancellationException || e instanceof YoutubeDL.CanceledException)
                    state("cancelled", "저장을 취소했습니다.", -1, "완료되지 않은 파일은 남기지 않습니다.");
                else state("failed", errorMessage(e.getMessage()), -1, clean(e.getMessage()));
            }
        } finally {
            finished = true;
            MediaPublisher.removeTree(directory);
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            // Finish on the main thread: a new job cannot race stopSelf / foreground cleanup.
            new android.os.Handler(getMainLooper()).post(() -> {
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            });
        }
    }
    private void checkCancelled() { if (cancelled.get()) throw new CancellationException(); }
    private void state(String phase, String message, int progress, String detail) {
        if (abandoned) return;
        store.state(phase, message, progress, detail);
        if (phase.equals("running")) getSystemService(NotificationManager.class).notify(NOTIFICATION, notification(message, progress));
    }
    private Notification notification(String message, int progress) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent cancel = PendingIntent.getService(this, 1, new Intent(this, SaveService.class).setAction(CANCEL), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_download)
                .setContentTitle(getString(R.string.app_name)).setContentText(message).setContentIntent(open)
                .setOnlyAlertOnce(true).setOngoing(true).setProgress(100, Math.max(0, progress), progress < 0)
                .addAction(new Notification.Action.Builder(null, "취소", cancel).build()).build();
    }
    static String clean(String message) {
        if (message == null) return "자세한 오류 정보가 없습니다.";
        String sanitized = message.replaceAll("\\x1b\\[[0-9;]*m", "")
                .replaceAll("https?://\\S+", "[주소 생략]");
        return sanitized.substring(0, Math.min(1800, sanitized.length()));
    }
    static String errorMessage(String message) {
        String error = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (error.contains("16 kb")) return "이 휴대폰에는 16 KB 지원 빌드가 필요합니다.";
        if (error.contains("sign in") || error.contains("login") || error.contains("private") || error.contains("members-only") || error.contains("age-restricted"))
            return "로그인 또는 별도 접근 권한이 필요한 영상입니다.";
        if (error.contains("drm")) return "보호된 영상은 저장할 수 없습니다.";
        if (error.contains("space") || error.contains("공간")) return "저장 공간을 확인한 뒤 다시 시도해 주세요.";
        if (error.contains("저장 폴더")) return "저장 폴더를 확인하거나 다시 선택해 주세요.";
        if (error.contains("음원 품질")) return "음원 품질을 바꾸고 다시 시도해 주세요.";
        if (error.contains("403") || error.contains("signature") || error.contains("challenge") || error.contains("format"))
            return "YouTube가 다운로드를 허용하지 않았거나 형식을 가져오지 못했습니다. 기능 업데이트 후 다시 시도해 주세요.";
        return "저장하지 못했습니다. 연결 상태와 링크를 확인해 주세요.";
    }
    @Override public void onTimeout(int startId, int fgsType) {
        store.state("failed", "Android의 백그라운드 작업 시간이 끝났습니다. 앱에서 다시 시도해 주세요.", -1, "");
        abandoned = true; cancelled.set(true);
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
    }
    @Override public void onDestroy() {
        if (!finished && store.state().busy()) store.state("failed", "저장이 중단되었습니다. 앱에서 다시 시도해 주세요.", -1, "");
        abandoned = true; cancelled.set(true); running = false;
        worker.shutdownNow(); canceller.shutdownNow();
        if (jobId != null) new Thread(() -> {
            try { YoutubeDL.getInstance().destroyProcessById(jobId); } catch (RuntimeException ignored) { }
        }, "save-cancel").start();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
