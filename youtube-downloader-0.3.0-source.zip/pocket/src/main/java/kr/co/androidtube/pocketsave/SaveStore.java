package kr.co.androidtube.pocketsave;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class SaveStore {
    record Item(String uri, String name, String mime, long time) { }
    record Task(String url, String mode, boolean updateOnly, String id, String quality, String folder) { }
    record State(String phase, String message, int progress, String detail) {
        boolean busy() { return phase.equals("running"); }
    }
    private final SharedPreferences preferences;
    SaveStore(Context context) { preferences = context.getSharedPreferences("saves", Context.MODE_PRIVATE); }
    void task(String url, String mode, boolean updateOnly) {
        task(url, mode, updateOnly, AudioQuality.defaultValue(mode), SaveDestination.DEFAULT_LABEL);
    }
    void task(String url, String mode, boolean updateOnly, String quality, String folder) {
        preferences.edit().putString("taskUrl", url).putString("taskMode", mode)
                .putString("taskQuality", quality).putString("taskFolder", folder)
                .putBoolean("taskUpdate", updateOnly).putString("taskId", java.util.UUID.randomUUID().toString()).apply();
    }
    Task task() {
        return new Task(preferences.getString("taskUrl", ""), preferences.getString("taskMode", ""),
                preferences.getBoolean("taskUpdate", false), preferences.getString("taskId", ""),
                preferences.getString("taskQuality", ""), preferences.getString("taskFolder", SaveDestination.DEFAULT_LABEL));
    }
    State state() {
        return new State(preferences.getString("phase", "idle"),
                preferences.getString("message", "저장할 YouTube 링크를 입력해 주세요."),
                preferences.getInt("progress", -1), preferences.getString("detail", ""));
    }
    void state(String phase, String message, int progress, String detail) {
        preferences.edit().putString("phase", phase).putString("message", message)
                .putInt("progress", progress).putString("detail", detail == null ? "" : detail).apply();
    }
    // A durable journal is needed before copying: apply() can lose the pending URI on process death.
    @android.annotation.SuppressLint("ApplySharedPref")
    void pending(String uri) {
        if (!preferences.edit().putString("pending", uri).remove("pendingDocument").commit())
            throw new IllegalStateException("저장 복구 정보를 기록하지 못했습니다.");
    }
    @android.annotation.SuppressLint("ApplySharedPref")
    void pendingDocument(String uri, String prefix) {
        if (!preferences.edit().putString("pending", uri).putString("pendingDocument", prefix).commit())
            throw new IllegalStateException("저장 복구 정보를 기록하지 못했습니다.");
    }
    String pendingDocument() { return preferences.getString("pendingDocument", null); }
    String pending() { return preferences.getString("pending", null); }
    List<Item> items() {
        List<Item> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(preferences.getString("items", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                result.add(new Item(o.getString("uri"), o.getString("name"), o.getString("mime"), o.getLong("time")));
            }
        } catch (Exception ignored) { }
        return result;
    }
    void add(Item item) {
        List<Item> all = items(); all.add(0, item);
        JSONArray array = new JSONArray();
        try {
            for (Item i : all.subList(0, Math.min(30, all.size()))) {
                array.put(new JSONObject().put("uri", i.uri()).put("name", i.name())
                        .put("mime", i.mime()).put("time", i.time()));
            }
            preferences.edit().putString("items", array.toString()).apply();
        } catch (Exception ignored) { }
    }
}
