package kr.co.androidtube.pocketsave;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.function.BooleanSupplier;

/** Publish only completed files; partial copies remain hidden and are removed on failure. */
final class MediaPublisher {
    static File result(File directory) throws IOException {
        File index = new File(directory, "result-path.txt");
        if (!index.isFile()) throw new IOException("완료된 파일이 없습니다. 실시간 방송은 종료된 후 다시 시도해 주세요.");
        String path = new String(Files.readAllBytes(index.toPath()), java.nio.charset.StandardCharsets.UTF_8).trim();
        File file = new File(path).getCanonicalFile();
        if (!directory.getCanonicalFile().equals(file.getParentFile()) || !file.getName().startsWith("media.")
                || !file.isFile() || file.length() == 0 || mime(extension(file)).equals("")) {
            throw new IOException("저장 결과 파일을 확인하지 못했습니다.");
        }
        return file;
    }
    static String safeTitle(String title) {
        String result = title.replaceAll("[\\p{Cntrl}/\\\\:*?\"<>|]", " ").replaceAll("\\s+", " ").trim();
        if (result.isEmpty() || result.equals(".") || result.equals("..")) result = "YouTube 영상";
        int count = result.codePointCount(0, result.length());
        if (count > 70) result = result.substring(0, result.offsetByCodePoints(0, 70));
        return result;
    }
    static String extension(File file) {
        return file.getName().substring(file.getName().lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
    }
    static String mime(String extension) {
        return switch (extension) {
            case "mp4" -> "video/mp4";
            case "mkv" -> "video/x-matroska";
            case "webm" -> "video/webm";
            case "m4a" -> "audio/mp4";
            case "mp3" -> "audio/mpeg";
            default -> "";
        };
    }
    static SaveStore.Item publish(Context context, File file, String title, String suffix,
                                  BooleanSupplier cancelled) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        SaveStore store = new SaveStore(context);
        String name = safeTitle(title) + "_" + suffix + "." + extension(file);
        String mime = mime(extension(file));
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, name);
        values.put(MediaStore.Downloads.MIME_TYPE, mime);
        values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/MoaSave");
        values.put(MediaStore.Downloads.IS_PENDING, 1);
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IOException("다운로드 폴더에 파일을 만들지 못했습니다.");
        boolean committed = false;
        try {
            store.pending(uri.toString());
            try (InputStream input = Files.newInputStream(file.toPath());
                 OutputStream output = resolver.openOutputStream(uri, "w")) {
                if (output == null) throw new IOException("저장 공간을 열지 못했습니다.");
                copy(input, output, cancelled);
            }
            if (cancelled.getAsBoolean()) throw new CancellationException();
            ContentValues ready = new ContentValues(); ready.put(MediaStore.Downloads.IS_PENDING, 0);
            if (resolver.update(uri, ready, null, null) != 1) throw new IOException("파일 저장을 완료하지 못했습니다.");
            committed = true;
            return new SaveStore.Item(uri.toString(), name, mime, System.currentTimeMillis());
        } finally {
            if (!committed) resolver.delete(uri, null, null);
            store.pending(null);
        }
    }
    static void copy(InputStream input, OutputStream output, BooleanSupplier cancelled) throws IOException {
        byte[] bytes = new byte[128 * 1024];
        for (int count; (count = input.read(bytes)) != -1;) {
            if (cancelled.getAsBoolean()) throw new CancellationException();
            output.write(bytes, 0, count);
        }
        if (cancelled.getAsBoolean()) throw new CancellationException();
    }
    static void recover(Context context) {
        SaveStore store = new SaveStore(context);
        String pending = store.pending();
        if (pending != null) {
            if (store.pendingDocument() != null) {
                try { DocumentPublisher.recover(context, pending, store.pendingDocument()); }
                catch (IOException | RuntimeException ignored) { }
                store.pending(null);
                return;
            }
            // Only delete a still-pending row. A crash after commit must not erase a complete file.
            try {
                Uri uri = Uri.parse(pending);
                try (android.database.Cursor cursor = context.getContentResolver().query(uri,
                        new String[]{MediaStore.Downloads.IS_PENDING}, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst() && cursor.getInt(0) == 1)
                        context.getContentResolver().delete(uri, null, null);
                }
            } catch (RuntimeException ignored) { }
            store.pending(null);
        }
    }
    static void removeTree(File file) {
        File[] children = file.listFiles();
        if (children != null) for (File child : children) removeTree(child);
        file.delete();
    }
}
