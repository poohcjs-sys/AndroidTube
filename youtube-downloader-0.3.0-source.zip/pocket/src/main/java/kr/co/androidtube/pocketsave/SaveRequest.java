package kr.co.androidtube.pocketsave;

import com.yausername.youtubedl_android.YoutubeDLRequest;
import java.io.File;
import java.util.Set;
import java.util.List;

final class SaveRequest {
    static final Set<String> MODES = Set.of("video720", "video1080", "m4a", "mp3");
    static String label(String mode) {
        return switch (mode) {
            case "video1080" -> "영상 · 최대 1080p";
            case "m4a" -> "음원 · M4A";
            case "mp3" -> "음원 · MP3";
            default -> "영상 · 최대 720p";
        };
    }
    static YoutubeDLRequest create(String link, String mode, File directory) {
        return create(link, mode, AudioQuality.defaultValue(mode), directory);
    }
    static YoutubeDLRequest create(String link, String mode, String quality, File directory) {
        if (!MODES.contains(mode)) throw new IllegalArgumentException("저장 형식을 다시 선택해 주세요.");
        quality = AudioQuality.validate(mode, quality);
        YoutubeDLRequest request = new YoutubeDLRequest(YouTubeLink.parse(link));
        request.addOption("--ignore-config").addOption("--no-playlist").addOption("--no-colors")
                .addOption("--newline").addOption("--no-mtime").addOption("--no-overwrites")
                .addOption("--socket-timeout", 20).addOption("--retries", 2)
                .addOption("--fragment-retries", 2).addOption("--abort-on-unavailable-fragments")
                .addOption("--match-filter", "!is_live & !is_upcoming")
                .addCommands(List.of("--print-to-file", "after_move:%(filepath)s", new File(directory, "result-path.txt").getAbsolutePath(),
                        "--print-to-file", "after_move:%(title)s", new File(directory, "title.txt").getAbsolutePath()))
                .addOption("--no-simulate")
                .addOption("-o", new File(directory, "media.%(ext)s").getAbsolutePath());
        if (mode.startsWith("video")) {
            int height = mode.equals("video1080") ? 1080 : 720;
            // MP4 + H.264/AAC when available; a playable WebM fallback is explicitly supported.
            request.addOption("-f", "bv[height<=" + height + "][ext=mp4][vcodec^=avc1]+ba[ext=m4a]/"
                    + "b[height<=" + height + "][ext=mp4]/bv[height<=" + height + "]+ba/b[height<=" + height + "]")
                    .addOption("--merge-output-format", "mp4/mkv");
        } else {
            request.addOption("-f", "ba[ext=m4a]/ba/b")
                    .addOption("-x").addOption("--audio-format", mode)
                    .addOption("--audio-quality", mode.equals("mp3") ? quality + "K" : "0");
        }
        return request;
    }
}
