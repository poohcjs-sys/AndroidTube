package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.DocumentsProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowContentResolver;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.CancellationException;

@RunWith(RobolectricTestRunner.class) @Config(sdk = 35)
public class DocumentPublicationTest {
    Context context; Storage provider; File input;
    final Uri tree = Uri.parse("content://personal.files/tree/music");
    @Before public void setUp() throws Exception {
        context = RuntimeEnvironment.getApplication();
        context.getSharedPreferences("saves", 0).edit().clear().commit();
        context.getSharedPreferences("download_settings", 0).edit().clear().commit();
        provider = new Storage(new File(context.getCacheDir(), "document-output"));
        ProviderInfo info = new ProviderInfo(); info.authority = "personal.files";
        info.exported = true; info.grantUriPermissions = true;
        info.readPermission = "android.permission.MANAGE_DOCUMENTS"; info.writePermission = "android.permission.MANAGE_DOCUMENTS";
        provider.attachInfo(context, info);
        ShadowContentResolver.registerProviderInternal("personal.files", provider);
        SaveDestination.accept(context, new Intent().setData(tree).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        input = new File(context.getCacheDir(), "media.mp3"); Files.write(input.toPath(), new byte[]{8, 9, 10});
    }
    @Test public void selectionPersistsAndBytesAreWrittenToTheSelectedTree() throws Exception {
        SaveDestination.Target target = SaveDestination.selected(context);
        assertEquals(tree.toString(), target.tree()); assertEquals("내 음악", target.label());
        assertTrue(SaveDestination.hasPermission(context, tree));
        var item = DocumentPublisher.publish(context, target, input, "좋아하는 노래", "unique", () -> false);
        assertEquals("좋아하는 노래_unique.mp3", item.name());
        assertEquals(item.name(), provider.name); assertTrue(provider.createdAsPartial);
        assertArrayEquals(Files.readAllBytes(input.toPath()), Files.readAllBytes(provider.output.toPath()));
        assertTrue(item.uri().startsWith("content://personal.files/tree/music/"));
        assertFalse(provider.deleted); assertNull(new SaveStore(context).pending());
        SaveDestination.useDefault(context); assertTrue(SaveDestination.selected(context).isDefault());
        assertTrue(SaveDestination.hasPermission(context, tree)); // Existing library files remain readable.
    }
    @Test public void cancellationDuringCopyRemovesTheStagingDocument() {
        java.util.concurrent.atomic.AtomicInteger checks = new java.util.concurrent.atomic.AtomicInteger();
        assertThrows(CancellationException.class, () -> DocumentPublisher.publish(context, SaveDestination.selected(context),
                input, "노래", "x", () -> checks.incrementAndGet() >= 2));
        assertTrue(provider.deleted); assertNull(new SaveStore(context).pending());
    }
    @Test public void renameFailureIsNotReportedAsSuccessfulDownload() {
        provider.failRename = true;
        assertThrows(IOException.class, () -> DocumentPublisher.publish(context, SaveDestination.selected(context), input, "노래", "x", () -> false));
        assertTrue(provider.deleted); assertNull(new SaveStore(context).pending());
    }
    @Test public void crashRecoveryRemovesOnlyStagingNamesAndPreservesCommittedFiles() {
        SaveStore store = new SaveStore(context);
        Uri uri = DocumentsContract.buildDocumentUriUsingTree(tree, "saved");
        provider.name = "yt-download-unique.partial.mp3";
        store.pendingDocument(uri.toString(), "yt-download-unique.partial"); MediaPublisher.recover(context);
        assertTrue(provider.deleted);
        provider.deleted = false; provider.name = "완성된 파일.mp3";
        store.pendingDocument(uri.toString(), "yt-download-unique.partial"); MediaPublisher.recover(context);
        assertFalse(provider.deleted); assertNull(store.pending());
    }
    @Test public void grantRevocationDoesNotRedirectToAnotherFolder() {
        context.getContentResolver().releasePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        assertThrows(IOException.class, () -> DocumentPublisher.publish(context, SaveDestination.selected(context), input, "노래", "x", () -> false));
        assertFalse(provider.createdAsPartial);
        assertEquals(tree.toString(), SaveDestination.selected(context).tree());
    }
    @Test public void readOnlyPickerResultDoesNotReplaceThePreviousFolder() {
        assertThrows(IOException.class, () -> SaveDestination.accept(context, new Intent().setData(Uri.parse("content://personal.files/tree/other"))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)));
        assertEquals(tree.toString(), SaveDestination.selected(context).tree());
    }
    static class Storage extends DocumentsProvider {
        final File output; String name = ""; boolean createdAsPartial, deleted, failRename;
        Storage(File output) { this.output = output; }
        @Override public boolean onCreate() { return true; }
        @Override public Cursor queryRoots(String[] projection) { return new MatrixCursor(new String[]{DocumentsContract.Root.COLUMN_ROOT_ID}); }
        @Override public Cursor queryDocument(String id, String[] projection) {
            String[] columns = projection != null ? projection : new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_FLAGS};
            MatrixCursor cursor = new MatrixCursor(columns); Object[] row = new Object[columns.length];
            for (int i = 0; i < columns.length; i++) row[i] = switch (columns[i]) {
                case DocumentsContract.Document.COLUMN_DOCUMENT_ID -> id;
                case DocumentsContract.Document.COLUMN_DISPLAY_NAME -> id.equals("music") ? "내 음악" : name;
                case DocumentsContract.Document.COLUMN_MIME_TYPE -> id.equals("music") ? DocumentsContract.Document.MIME_TYPE_DIR : "audio/mpeg";
                case DocumentsContract.Document.COLUMN_FLAGS -> DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE
                        | DocumentsContract.Document.FLAG_SUPPORTS_WRITE | DocumentsContract.Document.FLAG_SUPPORTS_RENAME | DocumentsContract.Document.FLAG_SUPPORTS_DELETE;
                default -> null;
            };
            cursor.addRow(row); return cursor;
        }
        @Override public Cursor queryChildDocuments(String parent, String[] projection, String sortOrder) { return queryDocument("saved", projection); }
        @Override public boolean isChildDocument(String parent, String child) { return parent.equals("music") && child.equals("saved"); }
        @Override public String createDocument(String parent, String mime, String name) {
            assertEquals("music", parent); assertEquals("audio/mpeg", mime);
            this.name = name; createdAsPartial = name.startsWith("yt-download-"); return "saved";
        }
        @Override public ParcelFileDescriptor openDocument(String id, String mode, CancellationSignal signal) throws FileNotFoundException {
            return ParcelFileDescriptor.open(output, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_TRUNCATE);
        }
        @Override public String renameDocument(String id, String name) throws FileNotFoundException {
            if (failRename) throw new FileNotFoundException("저장 폴더 이름 변경 실패");
            this.name = name; return id;
        }
        @Override public void deleteDocument(String id) { deleted = true; output.delete(); }
    }
}
