package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowContentResolver;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.util.concurrent.CancellationException;

@RunWith(RobolectricTestRunner.class) @Config(sdk = 35)
public class PublicationTest {
    Context context;
    Storage provider;
    File input;
    @Before public void setUp() throws Exception {
        context = RuntimeEnvironment.getApplication();
        context.getSharedPreferences("saves", 0).edit().clear().commit();
        provider = new Storage(new File(context.getCacheDir(), "published"));
        android.content.pm.ProviderInfo info = new android.content.pm.ProviderInfo();
        info.authority = "media"; info.exported = true;
        provider.attachInfo(context, info);
        ShadowContentResolver.registerProviderInternal("media", provider);
        input = new File(context.getCacheDir(), "media.mp3");
        Files.write(input.toPath(), new byte[]{10, 20, 30});
    }
    @Test public void fileIsMadeVisibleOnlyAfterAllBytesAreCopied() throws Exception {
        var item = MediaPublisher.publish(context, input, "내 음악/테스트", "unique", () -> false);
        assertEquals("audio/mpeg", item.mime());
        assertEquals("내 음악 테스트_unique.mp3", item.name());
        assertArrayEquals(new byte[]{10, 20, 30}, Files.readAllBytes(provider.output.toPath()));
        assertEquals(0, provider.pending); assertFalse(provider.deleted);
        assertEquals("Download/MoaSave", provider.values.getAsString(MediaStore.Downloads.RELATIVE_PATH));
        assertNull(new SaveStore(context).pending());
    }
    @Test public void cancelledPublicationDeletesHiddenPartialRow() {
        assertThrows(CancellationException.class, () -> MediaPublisher.publish(context, input, "音", "x", () -> true));
        assertTrue(provider.deleted); assertEquals(1, provider.pending);
        assertNull(new SaveStore(context).pending());
    }
    @Test public void failedCommitRollsBackInsteadOfReportingSuccess() {
        provider.failCommit = true;
        assertThrows(java.io.IOException.class, () -> MediaPublisher.publish(context, input, "音", "x", () -> false));
        assertTrue(provider.deleted);
    }
    @Test public void recoveryDeletesOnlyPendingRowsNotCompletedFiles() {
        SaveStore store = new SaveStore(context);
        store.pending("content://media/external/downloads/1"); provider.pending = 0;
        MediaPublisher.recover(context); assertFalse(provider.deleted);
        store.pending("content://media/external/downloads/1"); provider.pending = 1;
        MediaPublisher.recover(context); assertTrue(provider.deleted);
    }
    static class Storage extends ContentProvider {
        final File output; ContentValues values; int pending = 1; boolean deleted, failCommit;
        Storage(File output) { this.output = output; }
        @Override public boolean onCreate() { return true; }
        @Override public Uri insert(Uri uri, ContentValues values) {
            this.values = new ContentValues(values); pending = values.getAsInteger(MediaStore.Downloads.IS_PENDING);
            return Uri.parse("content://media/external/downloads/1");
        }
        @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
            return ParcelFileDescriptor.open(output, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_TRUNCATE);
        }
        @Override public int update(Uri uri, ContentValues values, String selection, String[] args) {
            if (failCommit) return 0;
            pending = values.getAsInteger(MediaStore.Downloads.IS_PENDING); return 1;
        }
        @Override public int delete(Uri uri, String selection, String[] args) { deleted = true; output.delete(); return 1; }
        @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
            MatrixCursor cursor = new MatrixCursor(new String[]{MediaStore.Downloads.IS_PENDING});
            cursor.addRow(new Object[]{pending}); return cursor;
        }
        @Override public String getType(Uri uri) { return "audio/mpeg"; }
    }
}
