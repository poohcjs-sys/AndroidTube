package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicBoolean;

public class SaveCoreTest {
    @Rule public TemporaryFolder temp = new TemporaryFolder();
    private static final String ID = "BaW_jenozKc";
    private static final String URL = "https://www.youtube.com/watch?v=" + ID;

    @Test public void sharedTextAndTrackingAreCanonicalized() {
        assertEquals(URL, YouTubeLink.parse("재미있는 영상\nhttps://youtu.be/" + ID + "?si=tracking&t=23"));
        assertEquals(URL, YouTubeLink.parse("https://www.youtube.com/watch?list=playlist&v=" + ID + "&index=3"));
        assertEquals(URL, YouTubeLink.parse("youtube.com/watch?v=" + ID));
    }
    @Test public void shortsMusicAndFinishedLiveLinksAccepted() {
        for (String path : List.of("https://m.youtube.com/shorts/", "https://www.youtube.com/live/", "https://www.youtube.com/embed/"))
            assertEquals(URL, YouTubeLink.parse(path + ID));
        assertEquals(URL, YouTubeLink.parse("https://music.youtube.com/watch?v=" + ID));
    }
    @Test public void otherHostsCredentialsPortsAndCommandsRejected() {
        for (String bad : List.of("https://youtube.com.evil.test/watch?v=" + ID,
                "https://www.youtube.com@evil.test/watch?v=" + ID,
                "https://user@www.youtube.com/watch?v=" + ID,
                "https://www.youtube.com:444/watch?v=" + ID,
                "https://youtu.be/" + ID + "/more", "file:///tmp/video", "--exec rm",
                "https://youtube.com/playlist?list=foo", "https://youtube.com/@someone", "https://youtu.be/too_short")) {
            assertThrows(bad, IllegalArgumentException.class, () -> YouTubeLink.parse(bad));
        }
    }
    @Test public void encodedCommandsAndInvalidIdsRejected() {
        assertThrows(IllegalArgumentException.class, () -> YouTubeLink.parse("https://youtube.com/watch?v=" + ID + "%0a--exec"));
        assertThrows(IllegalArgumentException.class, () -> YouTubeLink.parse("https://youtu.be/%2e%2e%2ftest"));
        assertThrows(IllegalArgumentException.class, () -> YouTubeLink.parse(null));
        assertThrows(IllegalArgumentException.class, () -> YouTubeLink.parse("x".repeat(16001)));
    }
    @Test public void requestCannotEnablePlaylistsLiveOrArbitraryCommands() throws Exception {
        File dir = temp.newFolder();
        var request = SaveRequest.create(URL + "&list=whole_channel", "video720", dir);
        assertTrue(request.hasOption("--no-playlist"));
        assertTrue(request.hasOption("--ignore-config"));
        assertEquals("!is_live & !is_upcoming", request.getOption("--match-filter"));
        List<String> args = request.buildCommand();
        assertEquals(URL, args.get(args.size() - 1));
        assertFalse(args.contains("--exec"));
        assertFalse(args.contains("--no-check-certificates"));
        int result = args.indexOf("--print-to-file");
        assertEquals("after_move:%(filepath)s", args.get(result + 1));
        assertEquals(new File(dir, "result-path.txt").getAbsolutePath(), args.get(result + 2));
        assertThrows(IllegalArgumentException.class, () -> SaveRequest.create(URL, "--exec", dir));
    }
    @Test public void audioDoesNotDownloadUnnecessaryVideoWhenAudioExists() throws Exception {
        var request = SaveRequest.create(URL, "mp3", temp.newFolder());
        assertTrue(request.hasOption("-x"));
        assertEquals("mp3", request.getOption("--audio-format"));
        assertEquals("192K", request.getOption("--audio-quality"));
        assertEquals("ba[ext=m4a]/ba/b", request.getOption("-f"));
    }
    @Test public void eachMp3QualityReachesTheEncoderAndInvalidValuesAreRejected() throws Exception {
        File directory = temp.newFolder();
        for (String quality : List.of("128", "192", "256", "320")) {
            var request = SaveRequest.create(URL, "mp3", quality, directory);
            assertEquals(quality + "K", request.getOption("--audio-quality"));
        }
        assertThrows(IllegalArgumentException.class, () -> SaveRequest.create(URL, "mp3", "0 --exec", directory));
        assertThrows(IllegalArgumentException.class, () -> SaveRequest.create(URL, "m4a", "320", directory));
    }
    @Test public void m4aNumericQualitiesExplicitlyEncodeInsteadOfSilentlyCopyingOriginal() throws Exception {
        File input = temp.newFile("source.m4a"), output = new File(temp.getRoot(), "encoded.m4a");
        for (String quality : List.of("128", "192", "256")) {
            List<String> command = AudioTranscoder.command("ffmpeg", input, output, quality);
            assertEquals("aac", command.get(command.indexOf("-c:a") + 1));
            assertEquals(quality + "k", command.get(command.indexOf("-b:a") + 1));
            assertFalse(command.contains("copy")); assertTrue(command.contains("-vn"));
        }
        assertThrows(IllegalArgumentException.class, () -> AudioTranscoder.command("ffmpeg", input, output, "original"));
        assertEquals("0", SaveRequest.create(URL, "m4a", "original", temp.newFolder()).getOption("--audio-quality"));
    }
    @Test public void resultsCannotEscapeJobDirectoryOrPublishPartialFiles() throws Exception {
        File dir = temp.newFolder(), external = temp.newFile("media.mp4");
        Files.write(external.toPath(), new byte[]{1});
        File index = new File(dir, "result-path.txt");
        Files.write(index.toPath(), external.getAbsolutePath().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertThrows(IOException.class, () -> MediaPublisher.result(dir));
        File partial = new File(dir, "media.mp4.part"); Files.write(partial.toPath(), new byte[]{1});
        Files.write(index.toPath(), partial.getAbsolutePath().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertThrows(IOException.class, () -> MediaPublisher.result(dir));
        File finalFile = new File(dir, "media.mp4"); Files.write(finalFile.toPath(), new byte[]{1, 2, 3});
        Files.write(index.toPath(), (finalFile.getAbsolutePath() + "\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertEquals(finalFile.getCanonicalFile(), MediaPublisher.result(dir));
    }
    @Test public void emptyOutputNeverBecomesSuccessfulDownload() throws Exception {
        File dir = temp.newFolder();
        File file = new File(dir, "media.m4a"); assertTrue(file.createNewFile());
        Files.write(new File(dir, "result-path.txt").toPath(), file.getAbsolutePath().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertThrows(IOException.class, () -> MediaPublisher.result(dir));
    }
    @Test public void unicodeTitleSurvivesAndCannotControlPaths() {
        assertEquals("딸과 함께 음악", MediaPublisher.safeTitle("딸과 함께/음악\n"));
        String title = MediaPublisher.safeTitle("🎵".repeat(100));
        assertEquals(70, title.codePointCount(0, title.length()));
        assertFalse(Character.isHighSurrogate(title.charAt(title.length() - 1)));
        assertEquals("YouTube 영상", MediaPublisher.safeTitle(".."));
    }
    @Test public void cancellationDuringCopyDoesNotContinueWriting() {
        AtomicBoolean cancelled = new AtomicBoolean();
        ByteArrayOutputStream output = new ByteArrayOutputStream() {
            @Override public void write(byte[] b, int off, int len) {
                super.write(b, off, len); cancelled.set(true);
            }
        };
        assertThrows(CancellationException.class, () -> MediaPublisher.copy(
                new ByteArrayInputStream(new byte[300000]), output, cancelled::get));
        assertTrue(output.size() > 0); assertTrue(output.size() < 300000);
    }
    @Test public void checksumRequiresExactExecutableName() throws Exception {
        String digest = "ab".repeat(32);
        assertEquals(digest, EngineUpdater.checksum(digest + "  yt-dlp\n"));
        assertThrows(IOException.class, () -> EngineUpdater.checksum(digest + "  yt-dlp.exe\n"));
        assertThrows(IOException.class, () -> EngineUpdater.checksum("bad  yt-dlp\n"));
    }
    @Test public void diagnosticsDoNotRetainSignedMediaUrls() {
        String clean = SaveService.clean("ERROR 403: https://media.test/video?token=secret\nretry failed");
        assertFalse(clean.contains("secret")); assertTrue(clean.contains("403"));
        assertTrue(SaveService.errorMessage("Sign in to confirm").contains("로그인"));
        assertTrue(SaveService.errorMessage("This video is DRM protected").contains("보호"));
    }
}
