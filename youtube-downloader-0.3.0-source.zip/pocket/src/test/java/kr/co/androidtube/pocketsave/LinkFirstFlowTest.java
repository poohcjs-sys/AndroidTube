package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class) @Config(sdk = 35)
public class LinkFirstFlowTest {
    private static final String LINK = "https://www.youtube.com/watch?v=BaW_jenozKc";
    @Before public void reset() {
        RuntimeEnvironment.getApplication().getSharedPreferences("saves", 0).edit().clear().commit();
        RuntimeEnvironment.getApplication().getSharedPreferences("MainActivity", 0).edit().clear().commit();
        SaveService.running = false;
    }
    private void confirm(MainActivity activity) {
        ((EditText) activity.findViewById(R.id.video_link)).setText(LINK);
        activity.findViewById(R.id.link_next).performClick();
    }
    @Test public void pasteThenContinueShowsFormatsWithoutStartingDownload() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get();
            assertNull(activity.findViewById(R.id.format_mp3));
            activity.getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("link", "https://youtu.be/BaW_jenozKc?si=tracking"));
            activity.findViewById(R.id.paste_link).performClick();
            assertEquals(LINK, ((EditText) activity.findViewById(R.id.video_link)).getText().toString());
            assertNull(activity.findViewById(R.id.format_mp3));
            activity.findViewById(R.id.link_next).performClick();
            assertNotNull(activity.findViewById(R.id.format_mp3));
            assertFalse(activity.findViewById(R.id.download_start).isEnabled());
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
        }
    }
    @Test public void invalidLinkStaysOnInputAndExplainsTheProblem() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get();
            ((EditText) activity.findViewById(R.id.video_link)).setText("https://youtube.com.evil.test/watch?v=BaW_jenozKc");
            activity.findViewById(R.id.link_next).performClick();
            assertEquals(View.VISIBLE, activity.findViewById(R.id.link_error).getVisibility());
            assertNull(activity.findViewById(R.id.format_720));
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
        }
    }
    @Test public void allFourSelectedFormatsReachServiceExactlyAsSelected() {
        String[] modes = {"video720", "video1080", "m4a", "mp3"};
        int[] ids = {R.id.format_720, R.id.format_1080, R.id.format_m4a, R.id.format_mp3};
        for (int i = 0; i < modes.length; i++) {
            try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
                MainActivity activity = controller.get(); confirm(activity);
                activity.findViewById(ids[i]).performClick();
                assertTrue(activity.findViewById(ids[i]).isSelected());
                assertTrue(activity.findViewById(R.id.download_start).isEnabled());
                assertNull(Shadows.shadowOf(activity).getNextStartedService());
                activity.findViewById(R.id.download_start).performClick();
                Intent command = Shadows.shadowOf(activity).getNextStartedService();
                assertNotNull(command); assertEquals(SaveService.SAVE, command.getAction());
                assertEquals(LINK, command.getStringExtra("url")); assertEquals(modes[i], command.getStringExtra("mode"));
                assertNull(Shadows.shadowOf(activity).getNextStartedService());
            }
        }
    }
    @Test public void choosingAnotherFormatReplacesPreviousChoice() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); confirm(activity);
            activity.findViewById(R.id.format_1080).performClick(); activity.findViewById(R.id.format_m4a).performClick();
            assertFalse(activity.findViewById(R.id.format_1080).isSelected());
            activity.findViewById(R.id.download_start).performClick();
            assertEquals("m4a", Shadows.shadowOf(activity).getNextStartedService().getStringExtra("mode"));
        }
    }
    @Test public void editingLinkRequiresChoosingFormatAgain() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); confirm(activity);
            activity.findViewById(R.id.format_mp3).performClick(); activity.findViewById(R.id.link_edit).performClick();
            ((EditText) activity.findViewById(R.id.video_link)).setText("https://youtu.be/abcdefghijk");
            activity.findViewById(R.id.link_next).performClick();
            assertFalse(activity.findViewById(R.id.download_start).isEnabled());
            assertFalse(activity.findViewById(R.id.format_mp3).isSelected());
        }
    }
    @Test public void formatAndConfirmedLinkSurviveActivityRecreation() {
        Bundle saved = new Bundle();
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); confirm(activity);
            activity.findViewById(R.id.format_mp3).performClick();
            controller.saveInstanceState(saved);
        }
        try (var controller = Robolectric.buildActivity(MainActivity.class).create(saved).start().restoreInstanceState(saved).resume().visible()) {
            MainActivity activity = controller.get(); assertTrue(activity.findViewById(R.id.format_mp3).isSelected());
            activity.findViewById(R.id.download_start).performClick();
            Intent command = Shadows.shadowOf(activity).getNextStartedService();
            assertEquals(LINK, command.getStringExtra("url")); assertEquals("mp3", command.getStringExtra("mode"));
        }
    }
    @Test public void browsingLibraryDoesNotCancelActiveDownload() {
        SaveStore store = new SaveStore(RuntimeEnvironment.getApplication());
        store.task(LINK, "mp3", false); store.state("running", "내려받는 중", 45, ""); SaveService.running = true;
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); activity.findViewById(R.id.nav_library).performClick();
            activity.findViewById(R.id.nav_new).performClick();
            assertTrue(store.state().busy()); assertFalse(activity.findViewById(R.id.link_next).isEnabled());
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
        } finally { SaveService.running = false; }
    }
    @Test public void incomingShareRemainsAnOptionalPrefillWithoutSkippingUserSelection() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); confirm(activity); activity.findViewById(R.id.format_mp3).performClick();
            controller.newIntent(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "https://youtu.be/abcdefghijk"));
            assertNotNull(activity.findViewById(R.id.video_link)); assertNull(activity.findViewById(R.id.format_mp3));
            activity.findViewById(R.id.link_next).performClick();
            assertFalse(activity.findViewById(R.id.download_start).isEnabled());
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
        }
    }
    @Test public void cancellationCompletionReenablesReturnToInput() {
        SaveStore store = new SaveStore(RuntimeEnvironment.getApplication());
        store.task(LINK, "mp3", false); store.state("running", "다운로드 중", 30, ""); SaveService.running = true;
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); activity.findViewById(R.id.save_cancel).performClick();
            assertEquals(SaveService.CANCEL, Shadows.shadowOf(activity).getNextStartedService().getAction());
            assertFalse(activity.findViewById(R.id.save_cancel).isEnabled());
            SaveService.running = false; store.state("cancelled", "저장을 취소했습니다.", -1, "");
            Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(700));
            assertTrue(activity.findViewById(R.id.save_cancel).isEnabled());
            activity.findViewById(R.id.save_cancel).performClick(); assertNotNull(activity.findViewById(R.id.video_link));
        } finally { SaveService.running = false; }
    }
}
