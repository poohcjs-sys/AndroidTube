package kr.co.androidtube.pocketsave;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;
import android.widget.EditText;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assume;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import java.io.File;
import java.io.FileOutputStream;

/** Actual Android view renders for design inspection; these are not device screenshots. */
@RunWith(RobolectricTestRunner.class) @Config(sdk = 35, qualifiers = "ko-rKR-w412dp-h915dp-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class DesignPreviewTest {
    @Before public void reset() {
        RuntimeEnvironment.getApplication().getSharedPreferences("saves", 0).edit().clear().commit();
        RuntimeEnvironment.getApplication().getSharedPreferences("MainActivity", 0).edit().clear().commit();
        SaveService.running = false;
    }
    @Test public void renderInputFormatsLibraryAndProgress() throws Exception {
        Assume.assumeNotNull(System.getProperty("moa.screenshots"));
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            capture(controller.get(), "01-link");
        }
        // Use fresh view trees for each render. Native RenderNode caches from an earlier window
        // traversal can omit unchanged children when redrawn into a separate software bitmap.
        android.os.Bundle selection = new android.os.Bundle();
        selection.putString("page", "FORMAT"); selection.putString("draft", "https://www.youtube.com/watch?v=BaW_jenozKc");
        selection.putString("confirmed", "https://www.youtube.com/watch?v=BaW_jenozKc"); selection.putString("selected", "mp3");
        try (var controller = Robolectric.buildActivity(MainActivity.class).create(selection).start().resume().visible()) {
            capture(controller.get(), "02-formats");
        }
        SaveStore store = new SaveStore(RuntimeEnvironment.getApplication());
        store.add(new SaveStore.Item("content://media/external/downloads/11", "오후의 플레이리스트.mp3", "audio/mpeg", 1793401200000L));
        store.add(new SaveStore.Item("content://media/external/downloads/12", "기억하고 싶은 순간.mp4", "video/mp4", 1793487600000L));
        android.os.Bundle library = new android.os.Bundle(); library.putString("page", "LIBRARY");
        try (var controller = Robolectric.buildActivity(MainActivity.class).create(library).start().resume().visible()) {
            capture(controller.get(), "03-library");
        }
        store.task("https://www.youtube.com/watch?v=BaW_jenozKc", "mp3", false);
        store.state("running", "음원 · MP3 · 내려받는 중", 68, ""); SaveService.running = true;
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) { capture(controller.get(), "04-progress"); }
        finally { SaveService.running = false; }
    }
    private void capture(MainActivity activity, String name) throws Exception {
        org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();
        View root = activity.findViewById(R.id.screen_root);
        int width = 824, height = 1830;
        root.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
        root.layout(0, 0, width, height);
        Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); root.draw(new Canvas(image));
        File folder = new File(System.getProperty("moa.screenshots")); folder.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(folder, name + ".png"))) { image.compress(Bitmap.CompressFormat.PNG, 100, out); }
        image.recycle();
    }
}
