package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.Intent;
import android.widget.EditText;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class) @Config(sdk = 35)
public class PhoneFlowTest {
    @Before public void reset() {
        RuntimeEnvironment.getApplication().getSharedPreferences("saves", 0).edit().clear().commit();
        RuntimeEnvironment.getApplication().getSharedPreferences("MainActivity", 0).edit().clear().commit();
        SaveService.running = false;
    }
    @Test public void youtubeSharePrefillsWithoutStartingAnUnrequestedDownload() {
        Intent intent = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "https://youtu.be/BaW_jenozKc?si=tracking");
        try (var controller = Robolectric.buildActivity(MainActivity.class, intent).setup()) {
            MainActivity activity = controller.get();
            assertEquals("https://www.youtube.com/watch?v=BaW_jenozKc", ((EditText) activity.findViewById(R.id.video_link)).getText().toString());
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
        }
    }
    @Test public void oldRunningStateRecoversAfterProcessDeath() {
        SaveStore store = new SaveStore(RuntimeEnvironment.getApplication());
        store.state("running", "saving", 50, "");
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            assertFalse(store.state().busy());
            assertEquals("failed", store.state().phase());
        }
    }
    @Test public void reopeningUiDoesNotCancelRunningService() {
        SaveStore store = new SaveStore(RuntimeEnvironment.getApplication());
        store.state("running", "saving", 50, ""); SaveService.running = true;
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            assertTrue(store.state().busy());
        } finally { SaveService.running = false; }
    }
    @Test public void historyRetainsNewestItemsAndDoesNotOverwriteNames() {
        SaveStore store = new SaveStore(RuntimeEnvironment.getApplication());
        for (int i = 0; i < 35; i++) store.add(new SaveStore.Item("content://media/" + i, "이름 " + i, "audio/mp4", i));
        assertEquals(30, store.items().size());
        assertEquals("이름 34", store.items().get(0).name());
        assertEquals("content://media/5", store.items().get(29).uri());
    }
}
