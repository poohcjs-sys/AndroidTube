package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowAlertDialog;

@RunWith(RobolectricTestRunner.class) @Config(sdk = 35)
public class DownloadOptionsTest {
    private static final String LINK = "https://www.youtube.com/watch?v=BaW_jenozKc";
    @Before public void reset() {
        var context = RuntimeEnvironment.getApplication();
        for (String name : new String[]{"saves", "MainActivity", "download_settings"}) context.getSharedPreferences(name, 0).edit().clear().commit();
        context.getSystemService(ClipboardManager.class).clearPrimaryClip();
        SaveService.running = false;
    }
    private void clip(MainActivity activity, String value) {
        activity.getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("link", value));
    }
    private void formats(MainActivity activity) {
        ((EditText) activity.findViewById(R.id.video_link)).setText(LINK);
        activity.findViewById(R.id.link_next).performClick();
    }
    @Test public void fieldTapPastesOnlyOnUserActionWithoutStartingWork() {
        RuntimeEnvironment.getApplication().getSystemService(ClipboardManager.class)
                .setPrimaryClip(ClipData.newPlainText("link", "https://youtu.be/BaW_jenozKc?si=track"));
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); EditText input = activity.findViewById(R.id.video_link);
            assertEquals("", input.getText().toString());
            input.performClick(); assertEquals(LINK, input.getText().toString());
            assertNull(activity.findViewById(R.id.format_mp3));
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
        }
    }
    @Test public void repeatedTapPreservesEditsButNewClipboardLinkReplacesThem() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); EditText input = activity.findViewById(R.id.video_link);
            clip(activity, LINK); input.performClick(); input.setText("수정 중"); input.performClick();
            assertEquals("수정 중", input.getText().toString());
            clip(activity, "https://youtu.be/abcdefghijk"); input.performClick();
            assertEquals("https://www.youtube.com/watch?v=abcdefghijk", input.getText().toString());
            input.setText(""); input.performClick(); assertFalse(input.getText().toString().isEmpty());
        }
    }
    @Test public void unrelatedClipboardNeverOverwritesTheInput() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); EditText input = activity.findViewById(R.id.video_link);
            input.setText(LINK); clip(activity, "내 메모 1234"); input.performClick();
            assertEquals(LINK, input.getText().toString());
            assertEquals(View.GONE, activity.findViewById(R.id.link_error).getVisibility());
            activity.findViewById(R.id.paste_link).performClick();
            assertEquals(View.VISIBLE, activity.findViewById(R.id.link_error).getVisibility());
        }
    }
    @Test public void qualitySelectionIsRememberedSeparatelyAndSentWithTheDownload() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); formats(activity);
            activity.findViewById(R.id.format_mp3).performClick(); activity.findViewById(R.id.audio_quality).performClick();
            AlertDialog dialog = ShadowAlertDialog.getLatestAlertDialog();
            dialog.getListView().performItemClick(null, 3, 3);
            assertEquals("320", AudioQuality.selected(activity, "mp3"));
            activity.findViewById(R.id.format_m4a).performClick();
            assertEquals("original", AudioQuality.selected(activity, "m4a"));
            activity.findViewById(R.id.format_mp3).performClick(); activity.findViewById(R.id.download_start).performClick();
            Intent intent = Shadows.shadowOf(activity).getNextStartedService();
            assertEquals("320", intent.getStringExtra("quality"));
            assertEquals("", intent.getStringExtra("folderUri"));
            assertEquals(SaveDestination.DEFAULT_LABEL, intent.getStringExtra("folderLabel"));
        }
    }
    @Test public void folderPickerCancellationKeepsExistingDestination() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get(); formats(activity);
            activity.findViewById(R.id.save_folder).performClick();
            ShadowAlertDialog.getLatestAlertDialog().getListView().performItemClick(null, 0, 0);
            var started = Shadows.shadowOf(activity).getNextStartedActivityForResult();
            assertEquals(Intent.ACTION_OPEN_DOCUMENT_TREE, started.intent.getAction());
            assertTrue((started.intent.getFlags() & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0);
            activity.onActivityResult(started.requestCode, Activity.RESULT_CANCELED, null);
            assertTrue(SaveDestination.selected(activity).isDefault());
        }
    }
    @Test public void revokedFolderGrantStopsBeforeDownloadingAndKeepsTheSelection() {
        try (var controller = Robolectric.buildActivity(MainActivity.class).setup()) {
            MainActivity activity = controller.get();
            String tree = "content://files/tree/MyMusic";
            activity.getSharedPreferences("download_settings", 0).edit().putString("folder_uri", tree).putString("folder_name", "내 음악").commit();
            formats(activity); activity.findViewById(R.id.format_mp3).performClick(); activity.findViewById(R.id.download_start).performClick();
            assertNull(Shadows.shadowOf(activity).getNextStartedService());
            assertNotNull(activity.findViewById(R.id.download_start));
            assertEquals(tree, SaveDestination.selected(activity).tree());
            assertTrue(Shadows.shadowOf(ShadowAlertDialog.getLatestAlertDialog()).getMessage().toString().contains("권한"));
        }
    }
}
