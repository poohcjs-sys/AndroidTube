# 유튜브 다운로더 0.3.1 — 완료한 링크 자동 비우기

영상·음원 파일을 성공적으로 저장하면 링크 입력창이 자동으로 비워집니다. 완료 화면과 보관함의 파일은 유지합니다.

- 실패·취소한 작업의 링크는 재시도를 위해 남깁니다. 다운로드 엔진 업데이트 완료로는 입력을 지우지 않습니다.
- 다운로드 중 새로 입력하거나 공유한 다른 링크는 지우지 않습니다.
- 백그라운드에서 완료되어도 앱을 다시 열면 완료한 링크를 정리합니다. 화면 회전이나 재실행으로 예전 링크가 되살아나지 않습니다.
- 클립보드에 남은 완료 링크는 입력창을 눌러도 자동으로 다시 붙지 않습니다. 같은 영상을 다시 받으려면 **복사한 링크 붙여넣기** 버튼이나 Android의 붙여넣기 메뉴를 사용합니다. 클립보드 자체는 삭제하지 않습니다.

[설치 APK](../releases/youtube-downloader-0.3.1/youtube-downloader-0.3.1-arm64.apk) · [소스 ZIP](../releases/youtube-downloader-0.3.1/youtube-downloader-0.3.1-source.zip) · [검증 기록](../releases/youtube-downloader-0.3.1/verification.json)

기존 앱을 삭제하지 않고 업데이트하세요. 앱 ID `kr.co.androidtube.pocketsave`와 서명을 유지하며 버전 코드는 4입니다. 저장한 파일·보관함·품질·폴더 설정을 유지합니다. Android 11 이상 ARM64용입니다.

자동 테스트 50개 통과, 선택적 디자인 이미지 생성 테스트 1개 생략. 완료·실패·취소·백그라운드·화면 복원·새 입력 보존·서비스 종료 중 재공유를 확인했습니다. APK 빌드와 Lint도 통과했습니다(오류·경고 0개). 다운로드 엔진은 변경하지 않았으며 실제 휴대폰 다운로드는 이번 환경에서 재시험하지 않았습니다.

```sh
source scripts/cloud-env.sh
./gradlew :pocket:testDebugUnitTest :pocket:assembleDebug :pocket:lintDebug --console=plain
```
