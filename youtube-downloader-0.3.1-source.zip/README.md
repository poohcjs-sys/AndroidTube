# YouTube Downloader 0.3.1

JDK 17 and Android SDK 35 are required. Set ANDROID_HOME and JAVA_HOME, then run `./gradlew :pocket:assembleDebug :pocket:testDebugUnitTest`. This build includes only the downloader. New signing keys will not replace an existing installed APK.

See pocket/LICENSE and pocket/THIRD_PARTY.md for source and licenses.
