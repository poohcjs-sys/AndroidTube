package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.widget.EditText;
import java.time.Duration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;

/** Completion notifications reconcile the existing draft without deleting a new user's input. */
@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class CompletedLinkFlowTest {
    private static final String LINK="https://www.youtube.com/watch?v=BaW_jenozKc";
    private static final String NEXT="https://www.youtube.com/watch?v=abcdefghijk";
    private SaveStore store;
    @Before public void reset(){
        var app=RuntimeEnvironment.getApplication();
        app.getSharedPreferences("saves",0).edit().clear().commit();
        app.getSharedPreferences("MainActivity",0).edit().clear().putString("link",LINK).commit();
        app.getSystemService(ClipboardManager.class).clearPrimaryClip();
        SaveService.running=false;store=new SaveStore(app);
    }
    private void running(){store.task(LINK,"mp3",false);store.state("running","저장 중",45,"");SaveService.running=true;}
    private void done(){store.add(new SaveStore.Item("content://media/external/audio/media/1","완료.mp3","audio/mpeg",1));store.state("done","저장 완료",100,"");SaveService.running=false;}
    private static void tick(){Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(700));}
    private static EditText input(MainActivity a){return a.findViewById(R.id.video_link);}

    @Test public void successClearsVisibleInputAndPersistenceButKeepsFileAndExplicitPaste(){
        running();
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            var a=c.get();a.findViewById(R.id.nav_new).performClick();
            a.getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("link",LINK));
            done();tick();assertEquals("",input(a).getText().toString());
            assertEquals("",a.getPreferences(0).getString("link","missing"));assertEquals(1,store.items().size());
            input(a).performClick();assertEquals("",input(a).getText().toString());
            assertEquals(LINK,a.getSystemService(ClipboardManager.class).getPrimaryClip().getItemAt(0).getText().toString());
            a.findViewById(R.id.paste_link).performClick();tick();assertEquals(LINK,input(a).getText().toString());
            assertNull(Shadows.shadowOf(a).getNextStartedService());
        }
    }
    @Test public void backgroundCompletionClearsOnNextLaunchAndDoesNotReturnAfterRecreation(){
        running();done();
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            assertEquals("",input(c.get()).getText().toString());
            c.recreate();tick();assertEquals("",input(c.get()).getText().toString());
        }
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            assertEquals("",input(c.get()).getText().toString());
        }
    }
    @Test public void olderSavedScreenCannotRestoreAnAlreadyConsumedCompletedLink(){
        running();Bundle saved=new Bundle();
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            c.get().findViewById(R.id.nav_new).performClick();c.saveInstanceState(saved);
            done();tick();assertEquals("",input(c.get()).getText().toString());
        }
        try(var c=Robolectric.buildActivity(MainActivity.class).create(saved).start().restoreInstanceState(saved).resume().visible()){
            tick();assertEquals("",input(c.get()).getText().toString());
        }
    }
    @Test public void failedCancelledAndEngineUpdateKeepDraftForRetry(){
        for(String phase:new String[]{"failed","cancelled","done"}){
            store.task(phase.equals("done")?"":LINK,"mp3",phase.equals("done"));store.state(phase,"시험 상태",-1,"");
            try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
                tick();assertEquals(phase,LINK,input(c.get()).getText().toString());
            }
        }
    }
    @Test public void newDraftDuringDownloadSurvivesAndCompletionIsNotAppliedTwice(){
        running();
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            var a=c.get();a.findViewById(R.id.nav_new).performClick();input(a).setText(NEXT);input(a).setSelection(5);
            done();tick();assertEquals(NEXT,input(a).getText().toString());assertEquals(5,input(a).getSelectionStart());
            input(a).setText(LINK);tick();assertEquals(LINK,input(a).getText().toString());
            a.getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("link",NEXT));
            input(a).performClick();assertEquals(NEXT,input(a).getText().toString());
        }
    }
    @Test public void sameVideoSharedAgainIsAnExplicitNewInputEvenWhenOldTaskCompleted(){
        running();done();
        Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,LINK);
        try(var c=Robolectric.buildActivity(MainActivity.class,share).setup()){
            tick();assertEquals(LINK,input(c.get()).getText().toString());
            assertNull(Shadows.shadowOf(c.get()).getNextStartedService());
        }
    }
    @Test public void newShareDuringServiceShutdownIsNotMistakenForTheCompletedInput(){
        running();
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            store.state("done","저장 완료",100,"");
            // A real service sets done before onDestroy releases its running flag.
            assertTrue(SaveService.running);
            c.newIntent(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,LINK));
            SaveService.running=false;tick();assertEquals(LINK,input(c.get()).getText().toString());
        }finally{SaveService.running=false;}
    }
}
