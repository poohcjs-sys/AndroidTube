package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.BaseColumns;
import android.provider.DocumentsContract;
import android.provider.DocumentsProvider;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Set;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowContentResolver;

@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class LibraryFilesTest {
    private Context context;
    private Media media;
    private Documents documents;
    private final Uri tree=Uri.parse("content://library.files/tree/music");
    @Before public void setup(){
        context=RuntimeEnvironment.getApplication();media=new Media();documents=new Documents();
        ProviderInfo info=new ProviderInfo();info.authority="media";info.exported=true;
        media.attachInfo(context,info);ShadowContentResolver.registerProviderInternal("media",media);
        info=new ProviderInfo();info.authority="library.files";info.exported=true;info.grantUriPermissions=true;
        info.readPermission="android.permission.MANAGE_DOCUMENTS";info.writePermission="android.permission.MANAGE_DOCUMENTS";
        documents.attachInfo(context,info);ShadowContentResolver.registerProviderInternal("library.files",documents);
        context.getContentResolver().takePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION);
    }
    private SaveStore.Item media(String id){return item("content://media/external/downloads/"+id);}
    private SaveStore.Item document(String id){return item(DocumentsContract.buildDocumentUriUsingTree(tree,id).toString());}
    private SaveStore.Item item(String uri){return new SaveStore.Item(uri,"시험 파일.mp3","audio/mpeg",1);}


    @Test public void mediaOnlySuccessfulEmptyQueryMeansMissing(){
        var absent=media("2");
        var result=LibraryFiles.scan(context,List.of(media("1"),absent,media("3"),media("4"),media("5")));
        assertEquals(Set.of(absent),result.missing());assertEquals(3,result.unavailable());assertEquals(0,media.deletions);
    }
    @Test public void documentDeletionUsesCompleteParentListingAndQueriesEachTreeOnce(){
        var missing=document("removed");
        var result=LibraryFiles.scan(context,List.of(document("kept"),missing,document("kept-again")));
        assertEquals(Set.of(missing),result.missing());assertEquals(0,result.unavailable());
        assertEquals(1,documents.rootQueries);assertEquals(1,documents.childQueries);assertEquals(1,documents.fileQueries);assertEquals(0,documents.deletions);
    }
    @Test public void revokedReadGrantPreservesEntriesWithoutQueryingProvider(){
        context.getContentResolver().releasePersistableUriPermission(tree,Intent.FLAG_GRANT_READ_URI_PERMISSION);
        var result=LibraryFiles.scan(context,List.of(document("removed"),document("kept")));
        assertTrue(result.missing().isEmpty());assertEquals(2,result.unavailable());
        assertEquals(0,documents.rootQueries);assertEquals(0,documents.childQueries);
    }
    @Test public void offlineRootAndIncompleteListingsNeverPrune(){
        for(String mode:List.of("root-null","root-offline","root-denied","children-null","children-loading","children-error","children-throw","children-invalid")){
            documents.mode=mode;
            var result=LibraryFiles.scan(context,List.of(document("removed")));
            assertTrue(mode,result.missing().isEmpty());assertEquals(mode,1,result.unavailable());
        }
    }
    @Test public void emptyHealthyDirectoryPrunesAllOldEntriesButNeverDeletesFiles(){
        documents.mode="children-empty";var first=document("removed");var second=document("also-removed");
        var result=LibraryFiles.scan(context,List.of(first,second));
        assertEquals(Set.of(first,second),result.missing());assertEquals(0,result.unavailable());assertEquals(0,documents.deletions);
    }
    @Test public void treeProviderFailureIsCachedAcrossItsEntries(){
        documents.mode="root-denied";
        var result=LibraryFiles.scan(context,List.of(document("one"),document("two")));
        assertTrue(result.missing().isEmpty());assertEquals(2,result.unavailable());
        assertEquals(1,documents.rootQueries);assertEquals(0,documents.childQueries);
    }
    @Test public void movedDocumentWithStableReadableIdRemainsInLibrary(){
        documents.mode="file-present";
        var result=LibraryFiles.scan(context,List.of(document("moved")));
        assertTrue(result.missing().isEmpty());assertEquals(0,result.unavailable());
        assertEquals(1,documents.fileQueries);
    }
    @Test public void directDocumentErrorsOrLoadingKeepEntriesDespiteAbsenceFromParent(){
        for(String mode:List.of("file-denied","file-error","file-loading","file-error-extra")){
            documents.mode=mode;
            var result=LibraryFiles.scan(context,List.of(document("moved")));
            assertTrue(mode,result.missing().isEmpty());assertEquals(mode,1,result.unavailable());
        }
    }
    @Test public void mixedStoresKeepUnknownEntriesAndReturnExactMissingRecords(){
        var absentMedia=media("2");var absentDocument=document("removed");
        var result=LibraryFiles.scan(context,List.of(absentMedia,absentDocument,media("1"),document("kept"),item("content://unavailable.provider/file"),item("broken")));
        assertEquals(Set.of(absentMedia,absentDocument),result.missing());assertEquals(2,result.unavailable());
        assertEquals(0,media.deletions);assertEquals(0,documents.deletions);
    }
    private static final class Media extends ContentProvider {
        int deletions;
        @Override public boolean onCreate(){return true;}
        @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){
            String id=uri.getLastPathSegment();
            if(id.equals("3"))return null;
            if(id.equals("4"))throw new SecurityException("read grant revoked");
            if(id.equals("5"))throw new IllegalStateException("provider unavailable");
            MatrixCursor cursor=new MatrixCursor(new String[]{BaseColumns._ID});
            if(id.equals("1"))cursor.addRow(new Object[]{1});return cursor;
        }
        @Override public Uri insert(Uri uri,ContentValues values){throw new AssertionError("read only");}
        @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new AssertionError("read only");}
        @Override public int delete(Uri uri,String selection,String[] args){deletions++;return 1;}
        @Override public String getType(Uri uri){return "audio/mpeg";}
    }
    private static final class Documents extends DocumentsProvider {
        String mode="normal";int rootQueries,childQueries,fileQueries,deletions;
        @Override public boolean onCreate(){return true;}
        @Override public Cursor queryRoots(String[] projection){return new MatrixCursor(new String[]{DocumentsContract.Root.COLUMN_ROOT_ID});}
        @Override public Cursor queryDocument(String id,String[] projection)throws FileNotFoundException{
            if(!id.equals("music")){
                fileQueries++;
                if(mode.equals("file-denied"))throw new SecurityException("grant lost during scan");
                if(mode.equals("file-error"))throw new IllegalStateException("document temporarily unavailable");
                if(!mode.startsWith("file-"))return null;
                MatrixCursor cursor=new MatrixCursor(new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID});
                Bundle extras=new Bundle();
                if(mode.equals("file-loading"))extras.putBoolean(DocumentsContract.EXTRA_LOADING,true);
                if(mode.equals("file-error-extra"))extras.putString(DocumentsContract.EXTRA_ERROR,"Offline");
                cursor.setExtras(extras);
                if(mode.equals("file-present"))cursor.addRow(new Object[]{id});
                return cursor;
            }
            rootQueries++;
            if(mode.equals("root-null"))return null;
            if(mode.equals("root-offline"))throw new FileNotFoundException("storage disconnected");
            if(mode.equals("root-denied"))throw new SecurityException("permission revoked");
            MatrixCursor cursor=new MatrixCursor(new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_MIME_TYPE});
            cursor.addRow(new Object[]{"music",DocumentsContract.Document.MIME_TYPE_DIR});return cursor;
        }
        @Override public Cursor queryChildDocuments(String parent,String[] projection,String order){
            childQueries++;
            if(mode.equals("children-null"))return null;
            if(mode.equals("children-throw"))throw new IllegalStateException("provider temporarily offline");
            MatrixCursor cursor=new MatrixCursor(new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID});
            Bundle extras=new Bundle();
            if(mode.equals("children-loading"))extras.putBoolean(DocumentsContract.EXTRA_LOADING,true);
            if(mode.equals("children-error"))extras.putString(DocumentsContract.EXTRA_ERROR,"Offline");
            cursor.setExtras(extras);
            if(mode.equals("children-invalid"))cursor.addRow(new Object[]{null});
            else if(!mode.equals("children-empty")){cursor.addRow(new Object[]{"kept"});cursor.addRow(new Object[]{"kept-again"});}
            return cursor;
        }
        @Override public boolean isChildDocument(String parent,String child){return parent.equals("music");}
        @Override public ParcelFileDescriptor openDocument(String id,String mode,CancellationSignal signal){throw new AssertionError("query only");}
        @Override public void deleteDocument(String id){deletions++;}
    }
}
