package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.BaseColumns;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowContentResolver;

@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class LibraryFlowTest {
    private SaveStore store; private Files provider;
    private static SaveStore.Item item(int id){return new SaveStore.Item("content://media/external/downloads/"+id,"파일-"+id+".mp3","audio/mpeg",id);}
    @Before public void reset(){
        var app=RuntimeEnvironment.getApplication();
        for(String name:List.of("saves","MainActivity"))app.getSharedPreferences(name,0).edit().clear().commit();
        SaveService.running=false;store=new SaveStore(app);provider=new Files();
        ProviderInfo info=new ProviderInfo();info.authority="media";provider.attachInfo(app,info);
        ShadowContentResolver.registerProviderInternal("media",provider);
    }
    private Tasks worker(MainActivity activity)throws Exception{
        Field field=MainActivity.class.getDeclaredField("libraryWorker");field.setAccessible(true);
        ((ExecutorService)field.get(activity)).shutdownNow();Tasks tasks=new Tasks();field.set(activity,tasks);return tasks;
    }
    private static String text(View view){
        if(view==null||view.getVisibility()!=View.VISIBLE)return "";
        StringBuilder value=new StringBuilder(view instanceof TextView t?t.getText():"");
        if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++)value.append('\n').append(text(group.getChildAt(i)));
        return value.toString();
    }
    private static void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}

    @Test public void libraryEntryAndReturnFromFileManagerPruneDeletedRowsAndUpdateCount()throws Exception{
        store.add(item(1));store.add(item(2));provider.present.add(1);
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            var a=c.get();Tasks tasks=worker(a);a.findViewById(R.id.nav_library).performClick();
            assertEquals(0,provider.queries);assertFalse(a.findViewById(R.id.library_refresh).isEnabled());
            tasks.runAll();idle();assertEquals(List.of(item(1)),store.items());
            String contents=text(a.findViewById(R.id.page_body));assertTrue(contents.contains(item(1).name()));assertFalse(contents.contains(item(2).name()));
            assertTrue(((TextView)a.findViewById(R.id.library_count_text)).getText().toString().contains("1"));
            int queries=provider.queries;Shadows.shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3));tasks.runAll();assertEquals(queries,provider.queries);
            c.pause();provider.present.clear();c.resume();idle();tasks.runAll();idle();
            assertTrue(store.items().isEmpty());assertFalse(text(a.findViewById(R.id.page_body)).contains(item(1).name()));
            assertTrue(((TextView)a.findViewById(R.id.library_count_text)).getText().toString().contains("0"));assertEquals(0,provider.deletions);
        }
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            Tasks tasks=worker(c.get());c.get().findViewById(R.id.nav_library).performClick();tasks.runAll();idle();assertTrue(store.items().isEmpty());
        }
    }
    @Test public void refreshPreservesUnknownProviderFailuresAndRetriesAfterAccessReturns()throws Exception{
        store.add(item(1));provider.fail=true;
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            var a=c.get();Tasks tasks=worker(a);a.findViewById(R.id.nav_library).performClick();tasks.runAll();idle();
            assertEquals(List.of(item(1)),store.items());assertTrue(text(a.findViewById(R.id.library_status)).contains("유지"));
            provider.fail=false;a.findViewById(R.id.library_refresh).performClick();tasks.runAll();idle();
            assertTrue(store.items().isEmpty());assertEquals(0,provider.deletions);
        }
    }
    @Test public void cleanupDoesNotOverwriteDownloadsAddedWhileTheSnapshotWasBeingChecked()throws Exception{
        store.add(item(1));store.add(item(2));provider.present.add(1);
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            Tasks tasks=worker(c.get());c.get().findViewById(R.id.nav_library).performClick();
            SaveStore other=new SaveStore(c.get());other.add(item(3));
            SaveStore.Item replacement=new SaveStore.Item(item(2).uri(),"새 파일.mp3","audio/mpeg",200);other.add(replacement);
            tasks.runAll();idle();assertEquals(List.of(replacement,item(3),item(1)),store.items());assertEquals(0,provider.deletions);
        }
    }
    @Test public void deletedLatestCompletionDoesNotOpenAnotherOlderSavedFile(){
        store.add(item(1));store.task("https://www.youtube.com/watch?v=BaW_jenozKc","mp3",false);store.state("done","저장 완료",100,item(2).name());
        Bundle saved=new Bundle();saved.putString("page","TRANSFER");
        try(var c=Robolectric.buildActivity(MainActivity.class).create(saved).start().resume().visible()){
            TextView action=c.get().findViewById(R.id.save_cancel);assertEquals("링크 입력으로 돌아가기",action.getText().toString());
            action.performClick();assertNotNull(c.get().findViewById(R.id.video_link));assertNull(Shadows.shadowOf(c.get()).getNextStartedActivity());
        }
    }
    private static final class Tasks extends AbstractExecutorService{
        final ArrayDeque<Runnable> queue=new ArrayDeque<>();boolean stopped;
        public void execute(Runnable task){queue.add(task);}void runAll(){while(!queue.isEmpty())queue.remove().run();}
        public void shutdown(){stopped=true;}public List<Runnable> shutdownNow(){stopped=true;var tasks=new ArrayList<>(queue);queue.clear();return tasks;}
        public boolean isShutdown(){return stopped;}public boolean isTerminated(){return stopped&&queue.isEmpty();}public boolean awaitTermination(long t,TimeUnit u){return isTerminated();}
    }
    private static final class Files extends ContentProvider{
        final Set<Integer> present=new HashSet<>();int queries,deletions;boolean fail;
        public boolean onCreate(){return true;}
        public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){
            queries++;if(fail)throw new SecurityException("temporarily unavailable");
            MatrixCursor c=new MatrixCursor(new String[]{BaseColumns._ID});int id=Integer.parseInt(uri.getLastPathSegment());if(present.contains(id))c.addRow(new Object[]{id});return c;
        }
        public String getType(Uri uri){return "audio/mpeg";}public Uri insert(Uri u,ContentValues v){throw new AssertionError("read only");}
        public int update(Uri u,ContentValues v,String s,String[] a){throw new AssertionError("read only");}public int delete(Uri u,String s,String[] a){deletions++;return 1;}
    }
}
