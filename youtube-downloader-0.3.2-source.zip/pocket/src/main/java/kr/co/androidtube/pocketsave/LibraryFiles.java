package kr.co.androidtube.pocketsave;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.DocumentsContract;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Read-only reconciliation. Provider failures must never be treated as file deletion. */
final class LibraryFiles {
    record Scan(Set<SaveStore.Item> missing, int unavailable) { }
    private enum Presence { PRESENT, MISSING, UNKNOWN }
    private record Directory(Set<String> children, boolean complete) { }
    private static final Directory UNKNOWN_DIRECTORY = new Directory(Set.of(), false);

    static Scan scan(Context context, List<SaveStore.Item> items) {
        Set<SaveStore.Item> missing = new HashSet<>();
        Map<Uri, Directory> directories = new HashMap<>();
        int unavailable = 0;
        for (SaveStore.Item item : items) {
            Presence result = Presence.UNKNOWN;
            if (!Thread.currentThread().isInterrupted()) {
                try {
                    Uri uri = Uri.parse(item.uri());
                    if ("content".equals(uri.getScheme()) && uri.getAuthority() != null) {
                        if (DocumentsContract.isTreeUri(uri)) {
                            String rootId = DocumentsContract.getTreeDocumentId(uri);
                            String documentId = DocumentsContract.getDocumentId(uri);
                            Uri tree = DocumentsContract.buildTreeDocumentUri(uri.getAuthority(), rootId);
                            Directory directory = directories.get(tree);
                            if (directory == null) {
                                directory = directory(context, tree, rootId);
                                directories.put(tree, directory);
                            }
                            if (directory.complete()) result = directory.children().contains(documentId)
                                    ? Presence.PRESENT : absentChild(context, uri, documentId);
                        } else if ("media".equals(uri.getAuthority()) && uri.getPathSegments().size() >= 3
                                && uri.getLastPathSegment() != null && uri.getLastPathSegment().matches("[0-9]+")) {
                            result = media(context, uri);
                        }
                    }
                } catch (RuntimeException ignored) { /* Malformed URI, revoked grant or provider outage. */ }
            }
            if (result == Presence.MISSING) missing.add(item);
            else if (result == Presence.UNKNOWN) unavailable++;
        }
        return new Scan(Set.copyOf(missing), unavailable);
    }

    private static Presence media(Context context, Uri uri) {
        try (Cursor cursor = context.getContentResolver().query(uri,
                new String[]{BaseColumns._ID}, null, null, null)) {
            if (cursor == null || incomplete(cursor)) return Presence.UNKNOWN;
            boolean present = cursor.moveToFirst();
            return incomplete(cursor) ? Presence.UNKNOWN : present ? Presence.PRESENT : Presence.MISSING;
        }
    }

    private static Presence absentChild(Context context, Uri uri, String documentId) {
        // A moved file may keep its document ID and readable URI after leaving the original folder.
        // Null alone is not deletion evidence; here it is combined with a healthy parent listing.
        try (Cursor cursor = context.getContentResolver().query(uri,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID}, null, null)) {
            if (cursor == null) return Presence.MISSING;
            if (incomplete(cursor)) return Presence.UNKNOWN;
            boolean present = cursor.moveToFirst();
            if (incomplete(cursor)) return Presence.UNKNOWN;
            if (!present) return Presence.MISSING;
            int column = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            return column >= 0 && documentId.equals(cursor.getString(column)) ? Presence.PRESENT : Presence.UNKNOWN;
        }
    }

    private static Directory directory(Context context, Uri tree, String rootId) {
        try { return readDirectory(context, tree, rootId); }
        catch (RuntimeException ignored) { return UNKNOWN_DIRECTORY; }
    }

    private static Directory readDirectory(Context context, Uri tree, String rootId) {
        boolean readable = context.getContentResolver().getPersistedUriPermissions().stream()
                .anyMatch(grant -> grant.isReadPermission() && tree.equals(grant.getUri()));
        if (!readable) return UNKNOWN_DIRECTORY;
        Uri root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
        try (Cursor cursor = context.getContentResolver().query(root, new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null)) {
            if (cursor == null || incomplete(cursor) || !cursor.moveToFirst()) return UNKNOWN_DIRECTORY;
            int id = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int mime = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            if (id < 0 || mime < 0 || !rootId.equals(cursor.getString(id))
                    || !DocumentsContract.Document.MIME_TYPE_DIR.equals(cursor.getString(mime))
                    || incomplete(cursor)) return UNKNOWN_DIRECTORY;
        }
        // This app creates files directly under the chosen tree root. Some providers return null
        // for a deleted document, so a healthy, complete parent listing is the deletion evidence.
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        try (Cursor cursor = context.getContentResolver().query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID}, null, null)) {
            if (cursor == null || incomplete(cursor)) return UNKNOWN_DIRECTORY;
            int column = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            if (column < 0) return UNKNOWN_DIRECTORY;
            Set<String> ids = new HashSet<>();
            while (cursor.moveToNext()) {
                String id = cursor.getString(column);
                if (id == null || id.isEmpty() || Thread.currentThread().isInterrupted()) return UNKNOWN_DIRECTORY;
                ids.add(id);
            }
            return incomplete(cursor) ? UNKNOWN_DIRECTORY : new Directory(Set.copyOf(ids), true);
        }
    }

    private static boolean incomplete(Cursor cursor) {
        Bundle extras = cursor.getExtras();
        return extras != null && (extras.getBoolean(DocumentsContract.EXTRA_LOADING, false)
                || extras.containsKey(DocumentsContract.EXTRA_ERROR));
    }
}
