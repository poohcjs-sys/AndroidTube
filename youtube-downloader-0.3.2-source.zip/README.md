# YouTube Downloader 0.3.2

JDK 17 and Android SDK 35 are required. Set ANDROID_HOME and JAVA_HOME, then run `./gradlew :pocket:assembleDebug :pocket:testDebugUnitTest`. This build includes only the downloader. A newly generated signing key cannot update an APK signed by a different key.

See pocket/LICENSE and pocket/THIRD_PARTY.md for source and licenses.
