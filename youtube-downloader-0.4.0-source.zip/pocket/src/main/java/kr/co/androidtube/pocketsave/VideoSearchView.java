package kr.co.androidtube.pocketsave;

import static kr.co.androidtube.pocketsave.StudioStyle.*;

import android.content.Context;
import android.content.res.ColorStateList;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Native, explicit search flow. A result selection never starts a download by itself. */
// Created only in Java with its controller and callbacks; never inflated from XML.
@android.annotation.SuppressLint("ViewConstructor")
final class VideoSearchView extends LinearLayout {
    private final StudioStyle ui;
    private final VideoSearchController state;
    private final Consumer<VideoSearchClient.Video> select;
    private final BooleanSupplier busy;
    private final EditText query;
    private final Button submit,clear,cancel;
    private final TextView status,resultLabel;
    private final ProgressBar progress;
    private final LinearLayout results;
    private final List<Button> selectionButtons=new ArrayList<>();
    private List<VideoSearchClient.Video> renderedResults;
    private String renderedQuery;

    VideoSearchView(Context context,VideoSearchController state,Consumer<VideoSearchClient.Video> select,BooleanSupplier busy){
        super(context);this.ui=new StudioStyle(context);this.state=state;this.select=select;this.busy=busy;
        setOrientation(VERTICAL);setId(R.id.search_panel);
        ui.add(this,ui.label("FIND YOUR NEXT FAVORITE"),24);
        TextView title=ui.text("찾고, 골라서\n나만의 컬렉션으로.",28,INK,true);title.setLetterSpacing(-0.035f);title.setAccessibilityHeading(true);ui.add(this,title,12);
        ui.add(this,ui.text("영상 제목이나 채널 이름으로 YouTube를 검색하세요.",14,MUTED,false),12);

        LinearLayout card=card(18);ui.add(this,card,22);
        TextView label=ui.text("검색어",13,INK,true);label.setLabelFor(R.id.search_input);card.addView(label);
        LinearLayout inputRow=ui.row();ui.add(card,inputRow,12);
        query=new EditText(context);query.setId(R.id.search_input);query.setSingleLine(true);query.setTextSize(16);query.setTextColor(INK);query.setHintTextColor(MUTED);
        query.setInputType(InputType.TYPE_CLASS_TEXT);query.setImeOptions(EditorInfo.IME_ACTION_SEARCH|EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        query.setHint("예: 여행 브이로그, 피아노 연주");query.setContentDescription("YouTube 검색어");query.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        query.setSaveEnabled(false);query.setPadding(ui.dp(12),ui.dp(16),ui.dp(12),ui.dp(16));query.setBackground(ui.shape(PAPER,12,0));query.setText(state.draft);
        inputRow.addView(query,new LayoutParams(0,-2,1));
        clear=ui.button("×",false,null);clear.setId(R.id.search_clear);clear.setTextSize(22);clear.setPadding(ui.dp(6),ui.dp(8),ui.dp(6),ui.dp(8));clear.setContentDescription("검색어 지우기");
        LayoutParams clearSize=new LayoutParams(ui.dp(48),ui.dp(54));clearSize.leftMargin=ui.dp(8);inputRow.addView(clear,clearSize);
        clear.setOnClickListener(v->{query.setText("");query.requestFocus();});
        submit=ui.button("YouTube 검색",true,null);submit.setId(R.id.search_submit);ui.add(card,submit,14);submit.setOnClickListener(v->search());
        progress=new ProgressBar(context,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setIndeterminateTintList(ColorStateList.valueOf(GOLD));progress.setId(R.id.search_progress);
        LayoutParams progressSize=new LayoutParams(-1,ui.dp(3));progressSize.topMargin=ui.dp(14);card.addView(progress,progressSize);
        status=ui.text("",13,MUTED,false);status.setId(R.id.search_status);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);ui.add(card,status,12);
        cancel=ui.button("검색 취소",false,null);cancel.setId(R.id.search_cancel);ui.add(card,cancel,12);cancel.setOnClickListener(v->{state.cancel();refresh();});
        query.setOnEditorActionListener((v,action,event)->{if(action!=EditorInfo.IME_ACTION_SEARCH)return false;search();return true;});
        query.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence text,int start,int count,int after){}public void onTextChanged(CharSequence text,int start,int before,int count){state.setDraft(text.toString());updateControls();}public void afterTextChanged(Editable text){}});
        resultLabel=ui.text("",13,GOLD,true);resultLabel.setId(R.id.search_result_label);resultLabel.setAccessibilityHeading(true);ui.add(this,resultLabel,23);
        results=ui.column();results.setId(R.id.search_results);ui.add(this,results,2);
        ui.add(this,ui.text("검색 결과는 최대 15개를 보여줘요. 검색어를 구체적으로 바꾸면 원하는 영상을 더 쉽게 찾을 수 있어요.",12,MUTED,false),18);
        refresh();
    }
    private LinearLayout card(int padding){LinearLayout card=ui.column();card.setPadding(ui.dp(padding),ui.dp(padding),ui.dp(padding),ui.dp(padding));card.setBackground(ui.shape(CARD,22,LINE));return card;}
    private void search(){
        if(busy.getAsBoolean()||state.loading||query.getText().toString().trim().isEmpty())return;
        InputMethodManager keyboard=getContext().getSystemService(InputMethodManager.class);
        if(keyboard!=null)keyboard.hideSoftInputFromWindow(query.getWindowToken(),0);
        state.search(query.getText().toString());refresh();
    }
    private static void enabled(View view,boolean value){view.setEnabled(value);view.setAlpha(value?1f:0.45f);}
    private void updateControls(){
        boolean blocked=busy.getAsBoolean();
        enabled(submit,!blocked&&!state.loading&&!query.getText().toString().trim().isEmpty());enabled(clear,query.length()>0);
        submit.setText(state.loading?"검색하고 있어요…":"YouTube 검색");
        progress.setVisibility(state.loading?VISIBLE:GONE);cancel.setVisibility(state.loading?VISIBLE:GONE);
        for(Button button:selectionButtons)enabled(button,!blocked&&!state.loading);
    }
    void refresh(){
        updateControls();boolean blocked=busy.getAsBoolean();
        String message;int color=MUTED;
        if(state.loading)message="YouTube에서 영상을 찾고 있어요. 잠시만 기다려 주세요.";
        else if(blocked)message="진행 중인 작업이 끝난 뒤 검색하거나 영상을 선택할 수 있어요.";
        else if(!state.error.isEmpty()){message=state.error+(state.results.isEmpty()?"":"\n아래에는 이전 검색 결과가 남아 있어요.");color=ERROR;}
        else if(!state.results.isEmpty())message="영상을 선택하면 저장 형식과 품질을 고를 수 있어요.";
        else if(!state.searchedQuery.isEmpty())message="검색 결과가 없어요. 다른 단어나 채널 이름으로 다시 찾아보세요.";
        else message="검색어를 입력하고 검색 버튼을 눌러 주세요.";
        if(!message.contentEquals(status.getText()))status.setText(message);status.setTextColor(color);
        if(Objects.equals(renderedResults,state.results)&&Objects.equals(renderedQuery,state.searchedQuery))return;
        renderedResults=List.copyOf(state.results);renderedQuery=state.searchedQuery;results.removeAllViews();selectionButtons.clear();
        resultLabel.setText(state.searchedQuery.isEmpty()?"":"“"+state.searchedQuery+"” · 검색 결과 "+state.results.size()+"개");
        resultLabel.setVisibility(state.searchedQuery.isEmpty()?GONE:VISIBLE);
        int index=0;for(VideoSearchClient.Video video:state.results){
            LinearLayout card=card(18);ui.add(results,card,12);
            LinearLayout meta=ui.row();card.addView(meta);
            TextView number=ui.label(String.format(Locale.ROOT,"%02d  VIDEO",++index));meta.addView(number,new LayoutParams(0,-2,1));
            TextView length=ui.text(duration(video.durationSeconds()),12,GOLD,true);length.setPadding(ui.dp(9),ui.dp(5),ui.dp(9),ui.dp(5));length.setBackground(ui.shape(TINT,8,0));meta.addView(length);
            TextView title=ui.text(video.title(),17,INK,true);title.setMaxLines(4);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setAccessibilityHeading(true);ui.add(card,title,13);
            String channel=video.channel()==null||video.channel().isBlank()?"채널 정보 미제공":video.channel();
            TextView creator=ui.text(channel,13,MUTED,false);creator.setMaxLines(2);creator.setEllipsize(android.text.TextUtils.TruncateAt.END);ui.add(card,creator,9);
            Button choose=ui.button("이 영상 선택",false,"arrow");if(index==1)choose.setId(R.id.search_select_first);choose.setTag(video.id());choose.setContentDescription(video.title()+" 선택 · 저장 형식 고르기");ui.add(card,choose,16);selectionButtons.add(choose);
            choose.setOnClickListener(v->{if(!busy.getAsBoolean()&&!state.loading)select.accept(video);});
        }
        updateControls();
    }
    private static String duration(long seconds){
        if(seconds<0)return "길이 미제공";
        if(seconds>=3600)return String.format(Locale.ROOT,"%d:%02d:%02d",seconds/3600,(seconds%3600)/60,seconds%60);
        return String.format(Locale.ROOT,"%d:%02d",seconds/60,seconds%60);
    }
}
