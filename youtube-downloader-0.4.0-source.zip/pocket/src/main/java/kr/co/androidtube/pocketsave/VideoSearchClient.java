package kr.co.androidtube.pocketsave;

import android.content.Context;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

/** Public YouTube search metadata only; never downloads or publishes media. */
final class VideoSearchClient {
    static final int LIMIT = 15;
    static final int MAX_QUERY_LENGTH = 120;
    static final ReentrantLock ENGINE_LOCK = new ReentrantLock();
    private static final int MAX_RESPONSE_LENGTH = 1_000_000;
    private final Object jobsLock = new Object();
    private final Map<String, AtomicBoolean> jobs = new HashMap<>();
    private final LinkedHashSet<String> cancelledBeforeStart = new LinkedHashSet<>();

    record Video(String id, String title, String channel, long durationSeconds) {
        Video {
            if (id == null || !id.matches("[A-Za-z0-9_-]{11}")) throw new IllegalArgumentException("올바르지 않은 영상입니다.");
        }
        String url() { return "https://www.youtube.com/watch?v=" + id; }
    }

    static String normalizeQuery(String value) {
        if (value == null) throw new IllegalArgumentException("검색어를 입력해 주세요.");
        String query = value.replaceAll("[\\s\\p{Z}]+", " ").trim();
        if (query.isEmpty()) throw new IllegalArgumentException("검색어를 입력해 주세요.");
        if (query.length() > MAX_QUERY_LENGTH || query.matches(".*\\p{Cc}.*"))
            throw new IllegalArgumentException("검색어는 120자 이내로 입력해 주세요.");
        return query;
    }

    static YoutubeDLRequest request(String query) {
        // Query text is one positional ytsearch target, never option names or a shell command.
        YoutubeDLRequest request = new YoutubeDLRequest("ytsearch" + LIMIT + ":" + normalizeQuery(query));
        request.addOption("--ignore-config").addOption("--flat-playlist")
                .addOption("--skip-download").addOption("--simulate").addOption("--dump-single-json")
                .addOption("--no-write-playlist-metafiles").addOption("--no-cache-dir")
                .addOption("--no-colors").addOption("--quiet")
                .addOption("--playlist-end", LIMIT).addOption("--socket-timeout", 15)
                .addOption("--retries", 1).addOption("--extractor-retries", 1);
        return request;
    }

    List<Video> search(Context context, String query, String processId) throws IOException {
        if (!validProcessId(processId)) throw new IOException("검색 작업을 준비하지 못했습니다. 다시 시도해 주세요.");
        YoutubeDLRequest request;
        try { request = request(query); }
        catch (IllegalArgumentException invalid) { throw new IOException(invalid.getMessage(), invalid); }
        AtomicBoolean cancelled = new AtomicBoolean();
        synchronized (jobsLock) {
            if (jobs.containsKey(processId)) throw new IOException("이미 진행 중인 검색입니다.");
            cancelled.set(cancelledBeforeStart.remove(processId));
            jobs.put(processId, cancelled);
        }
        ScheduledExecutorService canceller = null;
        boolean engineLocked = false;
        try {
            checkCancelled(cancelled);
            ENGINE_LOCK.lockInterruptibly(); engineLocked = true;
            checkCancelled(cancelled);
            if (android.system.Os.sysconf(android.system.OsConstants._SC_PAGESIZE) > 4096)
                throw new IOException("이 휴대폰에는 16 KB 메모리 페이지를 지원하는 검색 엔진이 필요합니다.");
            // The library synchronizes init(). No downloader update or FFmpeg setup is requested.
            YoutubeDL engine = YoutubeDL.getInstance();
            engine.init(context.getApplicationContext());
            checkCancelled(cancelled);
            Thread worker = Thread.currentThread();
            canceller = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread thread = new Thread(r, "youtube-search-cancel"); thread.setDaemon(true); return thread;
            });
            // Native process registration happens inside execute(). Repeating cancellation closes
            // the race where a cancellation arrives immediately before that registration.
            canceller.scheduleWithFixedDelay(() -> {
                if (cancelled.get() || worker.isInterrupted()) {
                    try { engine.destroyProcessById(processId); } catch (RuntimeException ignored) { }
                }
            }, 0, 200, TimeUnit.MILLISECONDS);
            checkCancelled(cancelled);
            var response = engine.execute(request, processId, false);
            checkCancelled(cancelled);
            return parse(response.getOut());
        } catch (CancellationException cancelledSearch) {
            throw cancelledSearch;
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt(); throw new CancellationException("검색을 취소했습니다.");
        } catch (YoutubeDL.CanceledException cancelledSearch) {
            throw new CancellationException("검색을 취소했습니다.");
        } catch (IOException failure) {
            checkCancelled(cancelled); throw failure;
        } catch (Exception failure) {
            checkCancelled(cancelled); throw new IOException(searchError(failure.getMessage()), failure);
        } finally {
            if (canceller != null) canceller.shutdownNow();
            if (engineLocked) ENGINE_LOCK.unlock();
            synchronized (jobsLock) { jobs.remove(processId); }
        }
    }

    /** Non-blocking on the UI thread; native process termination is done by the search watchdog. */
    void cancel(String processId) {
        if (!validProcessId(processId)) return;
        synchronized (jobsLock) {
            AtomicBoolean running = jobs.get(processId);
            if (running != null) running.set(true);
            else {
                cancelledBeforeStart.add(processId);
                while (cancelledBeforeStart.size() > 64) cancelledBeforeStart.remove(cancelledBeforeStart.iterator().next());
            }
        }
    }

    private static boolean validProcessId(String id) {
        // The library passes this identifier to its process-cleanup shell helper.
        return id != null && id.matches("[A-Za-z0-9_-]{1,100}");
    }
    private static void checkCancelled(AtomicBoolean cancelled) {
        if (cancelled.get() || Thread.currentThread().isInterrupted()) throw new CancellationException("검색을 취소했습니다.");
    }

    static List<Video> parse(String json) throws IOException {
        if (json == null || json.isBlank() || json.length() > MAX_RESPONSE_LENGTH) throw invalidResponse();
        try {
            JSONTokener tokens = new JSONTokener(json);
            Object root = tokens.nextValue();
            if (!(root instanceof JSONObject object) || tokens.nextClean() != 0) throw invalidResponse();
            JSONArray entries = object.optJSONArray("entries");
            if (entries == null || entries.length() > 1000) throw invalidResponse();
            List<Video> videos = new ArrayList<>(); Set<String> seen = new HashSet<>();
            for (int i = 0; i < entries.length() && videos.size() < LIMIT; i++) {
                JSONObject entry = entries.optJSONObject(i); if (entry == null) continue;
                String id = text(entry, "id", 32), title = text(entry, "title", 300);
                if (!id.matches("[A-Za-z0-9_-]{11}") || title.isEmpty() || seen.contains(id) || unavailable(entry)) continue;
                String channel = text(entry, "channel", 120);
                if (channel.isEmpty()) channel = text(entry, "uploader", 120);
                if (channel.isEmpty()) channel = "채널 정보 없음";
                Object duration = entry.opt("duration"); long seconds = -1;
                if (duration instanceof Number number) {
                    double n = number.doubleValue();
                    if (Double.isFinite(n) && n >= 0 && n <= 31_536_000) seconds = (long) n;
                }
                videos.add(new Video(id, title, channel, seconds)); seen.add(id);
            }
            return List.copyOf(videos);
        } catch (org.json.JSONException invalid) { throw invalidResponse(); }
    }

    private static boolean unavailable(JSONObject entry) {
        String type = entry.optString("_type", ""), live = entry.optString("live_status", "");
        if (type.equals("playlist") || entry.optBoolean("is_live", false) || entry.optBoolean("is_upcoming", false)
                || Set.of("is_live", "is_upcoming", "post_live").contains(live)) return true;
        String availability = text(entry, "availability", 40);
        if (!availability.isEmpty() && !Set.of("public", "unlisted").contains(availability)) return true;
        return entry.optInt("age_limit", 0) >= 18;
    }
    private static String text(JSONObject object, String key, int max) {
        Object value = object.opt(key); if (!(value instanceof String text)) return "";
        String clean = text.replaceAll("[\\p{Cc}\\p{Cf}]+", " ").replaceAll("[\\s\\p{Z}]+", " ").trim();
        if (clean.length() <= max) return clean;
        int end = max; if (Character.isHighSurrogate(clean.charAt(end - 1))) end--;
        return clean.substring(0, end);
    }
    private static IOException invalidResponse() { return new IOException("검색 결과를 읽지 못했습니다. 다시 검색해 주세요."); }
    private static String searchError(String raw) {
        String value = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        if (value.contains("timed out") || value.contains("timeout")) return "YouTube 검색 응답이 늦어지고 있어요. 잠시 후 다시 검색해 주세요.";
        if (value.contains("403") || value.contains("429") || value.contains("sign in") || value.contains("captcha") || value.contains("bot"))
            return "YouTube에서 검색 요청을 제한했어요. 잠시 후 다시 시도하거나 링크 붙여넣기를 이용해 주세요.";
        return "YouTube 검색에 연결하지 못했습니다. 인터넷 연결을 확인하고, 계속 실패하면 설정의 다운로드 기능 업데이트를 실행해 주세요.";
    }
}
