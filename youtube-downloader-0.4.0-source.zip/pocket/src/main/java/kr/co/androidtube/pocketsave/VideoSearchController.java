package kr.co.androidtube.pocketsave;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/** Explicit, cancellable metadata searches. A stale job cannot replace a newer query. */
final class VideoSearchController implements AutoCloseable {
    interface Gateway {
        List<VideoSearchClient.Video> search(String query, String processId) throws IOException;
        void cancel(String processId);
    }
    String draft = "", searchedQuery = "", error = "";
    boolean loading;
    List<VideoSearchClient.Video> results = List.of();
    private final Gateway gateway;
    private final ExecutorService worker;
    private final Executor main;
    private final ScheduledExecutorService timer;
    private Runnable listener;
    private Flight flight;
    private boolean closed;
    private static final class Flight {
        final String id = "youtube-search-" + UUID.randomUUID();
        Future<?> work;
        ScheduledFuture<?> timeout;
    }
    VideoSearchController(Context context) {
        this(defaultGateway(context.getApplicationContext()), Executors.newSingleThreadExecutor(),
                new Handler(Looper.getMainLooper())::post, Executors.newSingleThreadScheduledExecutor());
    }
    VideoSearchController(Gateway gateway, ExecutorService worker, Executor main, ScheduledExecutorService timer) {
        this.gateway = gateway; this.worker = worker; this.main = main; this.timer = timer;
    }
    private static Gateway defaultGateway(Context context) {
        VideoSearchClient client = new VideoSearchClient();
        return new Gateway() {
            public List<VideoSearchClient.Video> search(String query, String id) throws IOException { return client.search(context, query, id); }
            public void cancel(String id) { client.cancel(id); }
        };
    }
    void setListener(Runnable value) { listener = value; }
    void setDraft(String value) { draft = value == null ? "" : value; }
    void search(String value) {
        if (closed) return;
        setDraft(value);
        String query = draft.trim();
        if (query.isEmpty() || query.length() > 120) {
            error = query.isEmpty() ? "검색할 제목이나 채널 이름을 입력해 주세요." : "검색어는 120자 이내로 입력해 주세요.";
            changed(); return;
        }
        stop();
        Flight current = new Flight(); flight = current;
        searchedQuery = query; error = ""; loading = true; results = List.of(); changed();
        current.timeout = timer.schedule(() -> main.execute(() -> {
            if (closed || flight != current) return;
            stop(); error = "검색 응답이 늦어 중지했어요. 인터넷 상태를 확인한 뒤 다시 검색해 주세요."; changed();
        }), 60, TimeUnit.SECONDS);
        current.work = worker.submit(() -> {
            try {
                List<VideoSearchClient.Video> found = List.copyOf(gateway.search(query, current.id));
                main.execute(() -> finish(current, found, ""));
            } catch (Exception e) {
                String message = e instanceof IOException && e.getMessage() != null && !e.getMessage().isBlank()
                        ? e.getMessage() : "검색을 완료하지 못했어요. 인터넷 상태를 확인한 뒤 다시 시도해 주세요.";
                main.execute(() -> finish(current, List.of(), message));
            }
        });
    }
    private void finish(Flight current, List<VideoSearchClient.Video> found, String problem) {
        if (closed || flight != current) return;
        if (current.timeout != null) current.timeout.cancel(false);
        flight = null; loading = false; results = found; error = problem; changed();
    }
    void cancel() {
        if (!loading) return;
        stop(); error = "검색을 중지했어요. 원할 때 다시 검색할 수 있어요."; changed();
    }
    private void stop() {
        Flight previous = flight; flight = null; loading = false;
        if (previous == null) return;
        if (previous.timeout != null) previous.timeout.cancel(false);
        if (previous.work != null) previous.work.cancel(true);
        gateway.cancel(previous.id);
    }
    private void changed() { if (listener != null) listener.run(); }
    @Override public void close() {
        if (closed) return;
        closed = true; listener = null; stop(); worker.shutdownNow(); timer.shutdownNow();
    }
}
