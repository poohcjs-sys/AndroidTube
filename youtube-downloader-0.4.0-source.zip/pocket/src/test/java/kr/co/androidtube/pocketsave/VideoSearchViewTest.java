package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.Assume;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

@RunWith(RobolectricTestRunner.class) @Config(sdk=35,qualifiers="ko-rKR-w412dp-h915dp-xhdpi")
public class VideoSearchViewTest {
    private static final VideoSearchClient.Video VIDEO=new VideoSearchClient.Video("BaW_jenozKc","합성 검색 영상 · 실제 검색 결과 아님","화면 검토용 채널",365);
    private static final class Gateway implements VideoSearchController.Gateway{
        int calls,cancels;String query="";boolean fail;
        public List<VideoSearchClient.Video> search(String text,String processId)throws IOException{calls++;query=text;if(fail)throw new IOException("시험 연결 오류");return List.of(VIDEO);}
        public void cancel(String processId){cancels++;}
    }
    private static final class Tasks extends AbstractExecutorService{
        final ArrayDeque<Runnable> queue=new ArrayDeque<>();boolean closed;
        public void execute(Runnable task){queue.add(task);}void runAll(){while(!queue.isEmpty())queue.remove().run();}
        public void shutdown(){closed=true;}public List<Runnable> shutdownNow(){closed=true;var result=new ArrayList<>(queue);queue.clear();return result;}
        public boolean isShutdown(){return closed;}public boolean isTerminated(){return closed&&queue.isEmpty();}public boolean awaitTermination(long time,TimeUnit unit){return isTerminated();}
    }
    private static final class Session implements AutoCloseable{
        final Gateway gateway=new Gateway();final Tasks worker=new Tasks();
        final VideoSearchController state=new VideoSearchController(gateway,worker,Runnable::run,Executors.newSingleThreadScheduledExecutor());
        final AtomicBoolean busy=new AtomicBoolean();final AtomicReference<VideoSearchClient.Video> chosen=new AtomicReference<>();
        VideoSearchView view(Activity activity){VideoSearchView view=new VideoSearchView(activity,state,chosen::set,busy::get);activity.setContentView(view);state.setListener(view::refresh);return view;}
        public void close(){state.close();}
    }
    private static String text(View view){
        if(view.getVisibility()!=View.VISIBLE)return "";
        StringBuilder content=new StringBuilder(view instanceof TextView label?label.getText():"");
        if(view instanceof ViewGroup group)for(int i=0;i<group.getChildCount();i++)content.append('\n').append(text(group.getChildAt(i)));
        return content.toString();
    }
    @Test public void constructionFocusTypingAndClearNeverSearchOrStartOtherApps(){
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            VideoSearchView view=session.view(activity.get());EditText input=view.findViewById(R.id.search_input);input.requestFocus();input.setText("피아노 연주");input.setSelection(3);
            view.refresh();assertEquals("피아노 연주",session.state.draft);assertSame(input,view.findViewById(R.id.search_input));assertEquals(3,input.getSelectionStart());assertTrue(input.hasFocus());
            view.findViewById(R.id.search_clear).performClick();assertEquals("",input.getText().toString());assertEquals("",session.state.draft);assertFalse(view.findViewById(R.id.search_submit).isEnabled());
            assertEquals(0,session.gateway.calls);assertTrue(session.worker.queue.isEmpty());assertNull(Shadows.shadowOf(activity.get()).getNextStartedActivity());assertNull(Shadows.shadowOf(activity.get()).getNextStartedService());
        }
    }
    @Test public void keyboardSearchShowsLoadingAndOnlySelectionReturnsVideoToCaller(){
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            VideoSearchView view=session.view(activity.get());EditText input=view.findViewById(R.id.search_input);input.setText("피아노 연주");input.onEditorAction(EditorInfo.IME_ACTION_SEARCH);
            assertTrue(session.state.loading);assertEquals(View.VISIBLE,view.findViewById(R.id.search_cancel).getVisibility());assertFalse(view.findViewById(R.id.search_submit).isEnabled());assertNull(session.chosen.get());
            session.worker.runAll();assertEquals(1,session.gateway.calls);assertEquals("피아노 연주",session.gateway.query);assertEquals(View.GONE,view.findViewById(R.id.search_cancel).getVisibility());
            assertTrue(text(view.findViewById(R.id.search_results)).contains("6:05"));view.findViewById(R.id.search_select_first).performClick();
            assertEquals(VIDEO,session.chosen.get());assertEquals("https://www.youtube.com/watch?v=BaW_jenozKc",session.chosen.get().url());assertEquals(1,session.gateway.calls);assertNull(Shadows.shadowOf(activity.get()).getNextStartedService());
        }
    }
    @Test public void resultCardsAndEditedDraftStayStableAcrossRepeatedRefreshes(){
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            session.state.results=List.of(VIDEO);session.state.searchedQuery="이전 검색";VideoSearchView view=session.view(activity.get());
            View first=view.findViewById(R.id.search_select_first);EditText input=view.findViewById(R.id.search_input);input.setText("다음 검색 초안");input.requestFocus();input.setSelection(4);
            for(int i=0;i<5;i++)view.refresh();assertSame(first,view.findViewById(R.id.search_select_first));assertSame(input,view.findViewById(R.id.search_input));assertEquals(4,input.getSelectionStart());assertTrue(input.hasFocus());
            assertEquals("다음 검색 초안",input.getText().toString());String label=text(view.findViewById(R.id.search_result_label));assertTrue(label.contains("이전 검색"));assertFalse(label.contains("다음 검색"));assertEquals(0,session.gateway.calls);
        }
    }
    @Test public void activeDownloadBlocksSearchAndSelectionButKeepsDraftEditable(){
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            session.state.results=List.of(VIDEO);session.state.searchedQuery="피아노";session.busy.set(true);VideoSearchView view=session.view(activity.get());EditText input=view.findViewById(R.id.search_input);input.setText("나중에 검색");input.onEditorAction(EditorInfo.IME_ACTION_SEARCH);
            assertFalse(view.findViewById(R.id.search_submit).isEnabled());assertFalse(view.findViewById(R.id.search_select_first).isEnabled());view.findViewById(R.id.search_select_first).performClick();assertNull(session.chosen.get());assertTrue(session.worker.queue.isEmpty());
            assertTrue(text(view.findViewById(R.id.search_status)).contains("진행 중인 작업"));session.busy.set(false);view.refresh();assertTrue(view.findViewById(R.id.search_submit).isEnabled());assertTrue(view.findViewById(R.id.search_select_first).isEnabled());assertEquals("나중에 검색",input.getText().toString());
        }
    }
    @Test public void failuresRemainVisibleAndCancellingDoesNotEraseTheDraft(){
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            VideoSearchView view=session.view(activity.get());EditText input=view.findViewById(R.id.search_input);input.setText("기타 연주");session.gateway.fail=true;view.findViewById(R.id.search_submit).performClick();session.worker.runAll();
            assertFalse(session.state.error.isEmpty());assertTrue(text(view.findViewById(R.id.search_status)).contains(session.state.error));assertEquals("기타 연주",input.getText().toString());
            session.gateway.fail=false;view.findViewById(R.id.search_submit).performClick();input.setText("수정한 검색어");view.findViewById(R.id.search_cancel).performClick();session.worker.runAll();assertFalse(session.state.loading);assertEquals("수정한 검색어",input.getText().toString());assertNull(session.chosen.get());
        }
    }
    @Test @GraphicsMode(GraphicsMode.Mode.NATIVE) public void renderClearlyLabelledSyntheticSearchResults()throws Exception{
        Assume.assumeNotNull(System.getProperty("moa.screenshots"));
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            fixture(session);render(activity.get(),session,"05-search-synthetic",824);
        }
    }
    @Test @Config(sdk=35,qualifiers="ko-rKR-w320dp-h720dp-xhdpi") @GraphicsMode(GraphicsMode.Mode.NATIVE) public void renderNarrowSearchWithLargeText()throws Exception{
        Assume.assumeNotNull(System.getProperty("moa.screenshots"));RuntimeEnvironment.setFontScale(1.3f);
        try(var activity=Robolectric.buildActivity(Activity.class).setup();var session=new Session()){
            fixture(session);render(activity.get(),session,"06-search-320dp-font130-synthetic",640);
        }finally{RuntimeEnvironment.setFontScale(1f);}
    }
    private static void fixture(Session session){session.state.draft="피아노 연주";session.state.searchedQuery="피아노 연주";session.state.results=List.of(VIDEO,new VideoSearchClient.Video("abcdefghijk","합성 영상 · 편안한 오후의 음악 모음","시험 채널 · 실제 검색 아님",3725));}
    private static void render(Activity activity,Session session,String name,int width)throws Exception{
        LinearLayout root=new LinearLayout(activity);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(StudioStyle.PAPER);root.setPadding(48,24,48,40);root.addView(new VideoSearchView(activity,session.state,session.chosen::set,session.busy::get));
        root.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));root.layout(0,0,width,root.getMeasuredHeight());
        Bitmap bitmap=Bitmap.createBitmap(width,root.getMeasuredHeight(),Bitmap.Config.ARGB_8888);root.draw(new Canvas(bitmap));File folder=new File(System.getProperty("moa.screenshots"));assertTrue(folder.isDirectory()||folder.mkdirs());
        try(FileOutputStream output=new FileOutputStream(new File(folder,name+".png"))){assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG,100,output));}finally{bitmap.recycle();}
    }
}
