package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CancellationException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class VideoSearchClientTest {
    private static JSONObject video(String id,String title)throws Exception{return new JSONObject().put("id",id).put("title",title).put("channel","채널");}
    private static String result(JSONObject... entries)throws Exception{JSONArray a=new JSONArray();for(var e:entries)a.put(e);return new JSONObject().put("entries",a).toString();}

    @Test public void searchRequestUsesOnlyMetadataAndTreatsUserTextAsOneTarget(){
        var request=VideoSearchClient.request("  한국 음악  --exec echo $(secret)  ");
        var args=request.buildCommand();
        assertEquals("ytsearch15:한국 음악 --exec echo $(secret)",args.get(args.size()-1));
        for(String option:List.of("--ignore-config","--flat-playlist","--skip-download","--simulate","--dump-single-json","--no-write-playlist-metafiles"))assertTrue(option,request.hasOption(option));
        assertEquals("15",request.getOption("--playlist-end"));assertFalse(args.contains("--exec"));assertFalse(args.contains("-o"));
        assertFalse(args.contains("--no-simulate"));assertFalse(args.contains("--no-check-certificates"));
    }
    @Test public void queryValidationRejectsEmptyLongAndControlInputButKeepsKorean(){
        for(String invalid:List.of("", " \n\t ","가".repeat(121),"music\u0000title"))assertThrows(IllegalArgumentException.class,()->VideoSearchClient.request(invalid));
        assertThrows(IllegalArgumentException.class,()->VideoSearchClient.request(null));
        assertEquals("아이와 함께 동요",VideoSearchClient.normalizeQuery(" 아이와\n함께\t동요 "));
    }
    @Test public void parsesTitlesChannelsAndOptionalDurationIntoCanonicalVideoUrls()throws Exception{
        var first=video("BaW_jenozKc","노래 & 이야기").put("duration",123.7).put("webpage_url","https://evil.test/not-used");
        var second=video("abcdefghijk","두 번째").put("channel",JSONObject.NULL).put("uploader","제작자").put("duration",JSONObject.NULL);
        var videos=VideoSearchClient.parse(result(first,second));
        assertEquals(2,videos.size());assertEquals("https://www.youtube.com/watch?v=BaW_jenozKc",videos.get(0).url());
        assertEquals("노래 & 이야기",videos.get(0).title());assertEquals(123,videos.get(0).durationSeconds());
        assertEquals("제작자",videos.get(1).channel());assertEquals(-1,videos.get(1).durationSeconds());
    }
    @Test public void skipsInvalidIdsDuplicateResultsLivePrivateAndUpcomingButKeepsFinishedLive()throws Exception{
        var valid=video("BaW_jenozKc","녹화 영상").put("live_status","was_live");
        String data=result(valid,video("BaW_jenozKc","중복"),video("bad-id","잘못된 영상"),
                video("abcdefghijk","생방송").put("is_live",true),video("bbbbbbbbbbb","예정 방송").put("live_status","is_upcoming"),
                video("ccccccccccc","비공개").put("availability","private"),video("ddddddddddd","멤버십").put("availability","subscriber_only"),
                video("eeeeeeeeeee","연령 제한").put("age_limit",18),video("fffffffffff","목록").put("_type","playlist"));
        assertEquals(List.of("BaW_jenozKc"),VideoSearchClient.parse(data).stream().map(VideoSearchClient.Video::id).toList());
    }
    @Test public void boundedResultsKeepAtMostFifteenAndSanitizePlainText()throws Exception{
        JSONArray entries=new JSONArray();
        for(int i=0;i<35;i++)entries.put(video(String.format(java.util.Locale.ROOT,"%011d",i),"제목\n"+"가".repeat(400)).put("channel","\u202E채널\u0000이름"));
        var videos=VideoSearchClient.parse(new JSONObject().put("entries",entries).toString());
        assertEquals(15,videos.size());assertTrue(videos.get(0).title().length()<=300);assertFalse(videos.get(0).title().contains("\n"));assertEquals("채널 이름",videos.get(0).channel());
        assertThrows(UnsupportedOperationException.class,()->videos.clear());
    }
    @Test public void invalidAndOversizedResponsesAreErrorsWhileAnEmptySearchIsValid()throws Exception{
        for(String invalid:List.of("", "[]", "{\"entries\":null}","{\"entries\":[]} trailing"," ".repeat(1_000_001)))assertThrows(IOException.class,()->VideoSearchClient.parse(invalid));
        assertThrows(IOException.class,()->VideoSearchClient.parse(null));assertTrue(VideoSearchClient.parse("{\"entries\":[]}").isEmpty());
        var values=VideoSearchClient.parse(result(video("abcdefghijk","미제공").put("duration",-5).put("channel",JSONObject.NULL)));
        assertEquals(-1,values.get(0).durationSeconds());assertEquals("채널 정보 없음",values.get(0).channel());
    }
    @Test public void cancellationBeforeSearchAvoidsEvenEngineInitialization(){
        VideoSearchClient client=new VideoSearchClient();client.cancel("search-123");
        assertThrows(CancellationException.class,()->client.search(null,"검색어","search-123"));
        assertThrows(IOException.class,()->client.search(null,"검색어","bad;id"));
    }
}
