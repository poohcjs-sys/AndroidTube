package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.Delayed;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.junit.Test;

public class VideoSearchControllerTest {
    static final class Tasks extends AbstractExecutorService {
        final ArrayDeque<Runnable> queue = new ArrayDeque<>(); boolean stopped;
        public void execute(Runnable r) { queue.add(r); }
        void runAll() { while (!queue.isEmpty()) queue.remove().run(); }
        public void shutdown() { stopped = true; }
        public List<Runnable> shutdownNow() { stopped = true; var all = new ArrayList<>(queue); queue.clear(); return all; }
        public boolean isShutdown() { return stopped; }
        public boolean isTerminated() { return stopped && queue.isEmpty(); }
        public boolean awaitTermination(long n, TimeUnit unit) { return isTerminated(); }
    }
    static final class Clock extends ScheduledThreadPoolExecutor {
        final List<Tick> pending = new ArrayList<>(); long seconds;
        Clock() { super(1); }
        public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
            seconds = unit.toSeconds(delay); Tick tick = new Tick(command); pending.add(tick); return tick;
        }
        void fire() { for (Tick t : List.copyOf(pending)) t.run(); pending.clear(); }
    }
    static final class Tick extends FutureTask<Void> implements ScheduledFuture<Void> {
        Tick(Runnable r) { super(r, null); }
        public long getDelay(TimeUnit unit) { return 0; }
        public int compareTo(Delayed other) { return 0; }
    }
    static final class Gateway implements VideoSearchController.Gateway {
        final List<String> queries = new ArrayList<>(), cancelled = new ArrayList<>(); boolean fail;
        public List<VideoSearchClient.Video> search(String query, String id) throws IOException {
            queries.add(query); if (fail) throw new IOException("시험 연결 오류");
            return List.of(new VideoSearchClient.Video("BaW_jenozKc", query + " 합성 영상", "시험 채널", 90));
        }
        public void cancel(String id) { cancelled.add(id); }
    }
    @Test public void noRequestUntilExplicitValidSearchAndDraftRemainsEditable() {
        Gateway gateway = new Gateway(); Tasks work = new Tasks(), main = new Tasks(); Clock clock = new Clock();
        try (var state = new VideoSearchController(gateway, work, main, clock)) {
            state.setDraft("피아노"); assertTrue(work.queue.isEmpty()); state.search("  ");
            assertFalse(state.loading); assertFalse(state.error.isEmpty()); assertTrue(work.queue.isEmpty());
            state.search("  피아노  "); state.setDraft("다음 검색어"); work.runAll(); main.runAll();
            assertEquals(List.of("피아노"), gateway.queries); assertEquals("피아노", state.searchedQuery);
            assertEquals("다음 검색어", state.draft); assertEquals(1, state.results.size()); assertFalse(state.loading);
            clock.fire(); main.runAll(); assertTrue(state.error.isEmpty());
        }
    }
    @Test public void olderSearchReplyCannotReplaceNewerQuery() {
        Gateway gateway = new Gateway(); Tasks work = new Tasks(), main = new Tasks(); Clock clock = new Clock();
        try (var state = new VideoSearchController(gateway, work, main, clock)) {
            state.search("첫 검색"); work.runAll(); state.search("둘째 검색"); main.runAll();
            assertTrue(state.loading); assertTrue(state.results.isEmpty()); assertEquals("둘째 검색", state.searchedQuery);
            work.runAll(); main.runAll(); assertEquals("둘째 검색 합성 영상", state.results.get(0).title());
            assertEquals(1, gateway.cancelled.size()); assertTrue(gateway.cancelled.get(0).startsWith("youtube-search-"));
        }
    }
    @Test public void cancelledReplyIsIgnoredAndUserCanRetry() {
        Gateway gateway = new Gateway(); Tasks work = new Tasks(), main = new Tasks(); Clock clock = new Clock();
        try (var state = new VideoSearchController(gateway, work, main, clock)) {
            state.search("여행"); work.runAll(); state.cancel(); main.runAll();
            assertFalse(state.loading); assertTrue(state.results.isEmpty()); assertEquals("여행", state.draft);
            state.search(state.draft); work.runAll(); main.runAll(); assertEquals(1, state.results.size());
        }
    }
    @Test public void minuteDeadlineCancelsOnlyTheSearchAndRejectsQueuedResult() {
        Gateway gateway = new Gateway(); Tasks work = new Tasks(), main = new Tasks(); Clock clock = new Clock();
        try (var state = new VideoSearchController(gateway, work, main, clock)) {
            state.search("검색 지연"); assertEquals(60, clock.seconds); clock.fire(); main.runAll(); work.runAll(); main.runAll();
            assertFalse(state.loading); assertTrue(state.results.isEmpty()); assertTrue(state.error.contains("응답이 늦어"));
            assertEquals(1, gateway.cancelled.size()); assertTrue(gateway.cancelled.get(0).startsWith("youtube-search-"));
            assertEquals("검색 지연", state.draft);
        }
    }
    @Test public void failureIsNotAnEmptySuccessfulSearchAndClosingStopsPendingWork() {
        Gateway gateway = new Gateway(); Tasks work = new Tasks(), main = new Tasks(); Clock clock = new Clock();
        var state = new VideoSearchController(gateway, work, main, clock);
        try {
            gateway.fail = true; state.search("음악"); work.runAll(); main.runAll();
            assertEquals("시험 연결 오류", state.error); assertFalse(state.loading); assertTrue(state.results.isEmpty());
            gateway.fail = false; state.search("마지막 검색"); work.runAll(); state.close(); main.runAll();
            assertTrue(state.results.isEmpty()); assertTrue(work.isShutdown()); assertTrue(clock.isShutdown());
            state.search("닫힌 후 검색"); assertTrue(work.queue.isEmpty());
        } finally { state.close(); }
    }
}
