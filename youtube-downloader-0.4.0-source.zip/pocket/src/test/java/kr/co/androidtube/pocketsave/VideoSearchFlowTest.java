package kr.co.androidtube.pocketsave;

import static org.junit.Assert.*;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.widget.EditText;
import java.lang.reflect.Field;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class VideoSearchFlowTest {
    @Before public void reset() {
        var app=RuntimeEnvironment.getApplication();
        for(String name:List.of("saves","MainActivity"))app.getSharedPreferences(name,0).edit().clear().commit();
        SaveService.running=false;
    }
    private VideoSearchController attach(MainActivity activity,VideoSearchControllerTest.Gateway gateway,VideoSearchControllerTest.Tasks work)throws Exception{
        Field field=MainActivity.class.getDeclaredField("searchState");field.setAccessible(true);((VideoSearchController)field.get(activity)).close();
        var state=new VideoSearchController(gateway,work,Runnable::run,new VideoSearchControllerTest.Clock());field.set(activity,state);
        state.setListener(()->{VideoSearchView view=activity.findViewById(R.id.search_panel);if(view!=null)view.refresh();});return state;
    }
    @Test public void nativeSearchSelectionRequiresFormatAndExplicitDownloadThenUsesSelectedCanonicalUrl()throws Exception{
        Shadows.shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(android.Manifest.permission.POST_NOTIFICATIONS);
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            var a=c.get();var gateway=new VideoSearchControllerTest.Gateway();var work=new VideoSearchControllerTest.Tasks();attach(a,gateway,work);
            a.findViewById(R.id.open_search).performClick();((EditText)a.findViewById(R.id.search_input)).setText("피아노");a.findViewById(R.id.search_submit).performClick();work.runAll();
            a.findViewById(R.id.search_select_first).performClick();assertNotNull(a.findViewById(R.id.format_mp3));assertFalse(a.findViewById(R.id.download_start).isEnabled());assertNull(Shadows.shadowOf(a).getNextStartedService());
            a.findViewById(R.id.link_edit).performClick();assertNotNull(a.findViewById(R.id.search_select_first));assertEquals(1,gateway.queries.size());
            a.findViewById(R.id.search_select_first).performClick();a.findViewById(R.id.format_mp3).performClick();a.findViewById(R.id.download_start).performClick();
            Intent command=Shadows.shadowOf(a).getNextStartedService();assertEquals(SaveService.SAVE,command.getAction());assertEquals("mp3",command.getStringExtra("mode"));assertEquals("https://www.youtube.com/watch?v=BaW_jenozKc",command.getStringExtra("url"));
            assertNull(Shadows.shadowOf(a).getNextStartedActivity());
        }
    }
    @Test public void rotationKeepsResultsAndQueryWithoutRepeatingTheSearch()throws Exception{
        try(var c=Robolectric.buildActivity(MainActivity.class).setup()){
            var gateway=new VideoSearchControllerTest.Gateway();var work=new VideoSearchControllerTest.Tasks();attach(c.get(),gateway,work);
            c.get().findViewById(R.id.nav_search).performClick();((EditText)c.get().findViewById(R.id.search_input)).setText("여행");c.get().findViewById(R.id.search_submit).performClick();work.runAll();
            c.recreate();Shadows.shadowOf(Looper.getMainLooper()).idle();assertNotNull(c.get().findViewById(R.id.search_select_first));assertEquals("여행",((EditText)c.get().findViewById(R.id.search_input)).getText().toString());assertEquals(1,gateway.queries.size());
        }
    }
    @Test public void processRecreationKeepsDraftWithoutStartingNetworkAutomatically(){
        Bundle saved=new Bundle();saved.putString("page","SEARCH");saved.putString("searchDraft","나중에 찾아볼 노래");
        try(var c=Robolectric.buildActivity(MainActivity.class).create(saved).start().resume().visible()){
            assertEquals("나중에 찾아볼 노래",((EditText)c.get().findViewById(R.id.search_input)).getText().toString());assertNull(c.get().findViewById(R.id.search_select_first));assertNull(Shadows.shadowOf(c.get()).getNextStartedService());
        }
    }
}
